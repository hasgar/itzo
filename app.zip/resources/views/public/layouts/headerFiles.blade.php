<!-- Meta -->
	<meta charset="utf-8">
	<meta name="keywords" content="Chikitzo" />
	<meta name="description" content="Chikitzo">
	<meta name="author" content="">

	<!-- Title -->

	<!-- Mobile Meta -->
	<meta name="viewport" content="width=device-width, initial-scale=1">

	<!-- Favicon -->
	<link rel="shortcut icon" href="/images/favicon.png" type="image/x-icon">

	<!-- CSS -->
	<link href="/lib/bootstrap/css/bootstrap.css" type="text/css" rel="stylesheet" />
	<link href="/css/colors.css" type="text/css" rel="stylesheet" />
	<link href="/css/font.css" type="text/css" rel="stylesheet" />
	<link href="/lib/jQuery.filer-master/css/jquery.filer.css" type="text/css" rel="stylesheet" />
	<link href="/lib/jQuery.filer-master/css/themes/jquery.filer-dragdropbox-theme.css" type="text/css" rel="stylesheet" />
	<link href="/lib/Magnific-Popup-master/magnific-popup.css" type="text/css" rel="stylesheet" />
	<link href="/lib/popup/css/component.css" type="text/css" rel="stylesheet" />
	<link href="/lib/icon8/styles.min.css" type="text/css" rel="stylesheet" />
	<link href="/lib/font-awesome/css/font-awesome.min.css" type="text/css" rel="stylesheet" />
	<link type="text/css" rel="stylesheet" href="/lib/jquerym.menu/css/jquery.mmenu.all.css" />

	<link href='/css/mapbox.css' rel='stylesheet' />
	<link href='/lib/chosen/chosen.css' rel='stylesheet' />
	<link href='/js/owl.carousel/owl-carousel/owl.carousel.css' rel='stylesheet' />
	<link href='/js/owl.carousel/owl-carousel/owl.transitions.css' rel='stylesheet' />
	<link href='/js/owl.carousel/owl-carousel/owl.theme.css' rel='stylesheet' />

	<link href='https://api.mapbox.com/mapbox.js/plugins/leaflet-markercluster/v0.4.0/MarkerCluster.css' rel='stylesheet' />
	<link href='https://api.mapbox.com/mapbox.js/plugins/leaflet-markercluster/v0.4.0/MarkerCluster.Default.css' rel='stylesheet' />
	<link href="/css/main.css" type="text/css" rel="stylesheet" />
	<meta name="csrf-token" content="{{ csrf_token() }}">
