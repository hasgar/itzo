Hello {{$name}} Team,

Thanks for registering with us.

Your OTP is: {{$otp}}

Regards,
Chikitzo Team
