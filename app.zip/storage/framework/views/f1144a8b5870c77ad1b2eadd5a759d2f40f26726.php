<?php $__env->startSection('title', 'Chat - Chikitzo'); ?>


<?php $__env->startSection('content'); ?>
<div id="page">
	<!--==================================Header Open=================================-->
	<header class="">


		
		<div class="md-overlay"></div> <!-- Overlay for Popup -->
							<div id="menu">
								<?php echo $__env->make('public.layouts.headerMob', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
							</div>
		<div class="lp-menu-bar  lp-menu-bar-color">
			<div class="container">
					<div class="row">
						<?php echo $__env->make('public.layouts.logo', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
						
					</div>
				</div>
		</div><!-- ../menu-bar -->
		<div class="page-heading listing-page archive-page ">
			<div class="page-heading-inner-container text-center">
				<h1>Chat</h1>
				<ul class="breadcrumbs">
					<li><a href="/">Home</a></li>
					<li><span>Chat</span></li>
				</ul>
			</div>
			<div class="page-header-overlay"></div>
		</div><!-- ../Home Search Container -->
	</header>
	<!--==================================Header Close=================================-->
	
	<!--==================================Section Open=================================-->
	<section>
		
		<div class="lp-section-row aliceblue">
			<div class="lp-section-content-container-one">
				<div class="container">
					<div class="row">
						<div class="col-md-12">
							<div class="login-form-popup lp-border-radius-8">
								<div class="siginincontainer chat-window">
									<h1 class="text-center">Chat</h1>

									
									<form class="form-horizontal margin-top-30" role="form" method="POST" action="<?php echo e(url('/user/chatSend')); ?>">
										<?php echo e(csrf_field()); ?>

										<input type="hidden" value="<?php echo e($booking[0]['id']); ?>" name="id" >
										<div class="col-md-10"><div class="form-group <?php echo e($errors->has('message') ? ' has-error' : ''); ?>">
											<input type="text" class="form-control chat-msg" placeholder="Type your message" id="message" name="message" value="<?php echo e(old('message')); ?>"/>
										<?php if($errors->has('email')): ?>
											<span class="help-block">
												<strong><?php echo e($errors->first('email')); ?></strong>
											</span>
										<?php endif; ?>
										</div>
										</div>
										<div class="col-md-2">
										<div class="form-group">
											<input type="submit" class="btn btn-warning chat-send" value="Send" class="btn btn-warning" /> 
										</div>
										</div>
									</form>	
									<div class="chat-box">
									<?php foreach($chat as $c): ?>
									<?php if($c['from_user'] == 'user'): ?>
									<div class="alert alert-success">
  <strong>You:</strong> <?php echo e($c['message']); ?>

</div>
<?php endif; ?>
<?php if($c['from_user'] == 'healthcare'): ?>
									<div class="alert alert-warning">
  <strong>They:</strong> <?php echo e($c['message']); ?>

</div>
<?php endif; ?>
<?php if($c['from_user'] == 'admin'): ?>
									<div class="alert alert-info">
  <strong>You:</strong> <?php echo e($c['message']); ?>

</div>
<?php endif; ?>
<?php endforeach; ?>
									</div>
									<div class="pop-form-bottom">
									

									</div>
								<a class="md-close"><i class="fa fa-close"></i></a>
								</div>
								
								
							</div>	
						</div>
					</div>
				</div>
			</div>
		</div><!-- ../section-row -->
	
	</section>
	
<?php $__env->stopSection(); ?>
<?php echo $__env->make('public.layouts.master', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>