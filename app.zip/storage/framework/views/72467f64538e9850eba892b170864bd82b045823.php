<?php $__env->startSection('title', 'Payment Pending - Chikitzo'); ?>


<?php $__env->startSection('content'); ?>
<div id="page">
	<!--==================================Header Open=================================-->
	<header class="">



		<div class="md-overlay"></div> <!-- Overlay for Popup -->
							<div id="menu">
								<?php echo $__env->make('public.layouts.headerMob', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
							</div>
		<div class="lp-menu-bar  lp-menu-bar-color">
			<div class="container">
					<div class="row">
						<?php echo $__env->make('public.layouts.logo', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>

					</div>
				</div>
		</div><!-- ../menu-bar -->

	</header>
	<!--==================================Header Close=================================-->

	<!--==================================Section Open=================================-->
	<section>

		<div class="lp-section-row aliceblue">
			<div class="lp-section-content-container-one">
				<div class="container">
					<div class="row">
						<div class="col-md-12">
							<div class="login-form-popup lp-border-radius-8">
								<div class="siginincontainer">
									<h1 class="text-center">Payment Pending</h1>
  									<p class="text-center">You are now one step away from registering <?php echo e($name); ?> </p>
	  									<p class="text-center">Please pay Rs. <?php echo e($amount); ?> for subscribing to chikitzo from <?php echo e($date_from); ?> to <?php echo e($date_to); ?> </p>

								<a class="md-close"><i class="fa fa-close"></i></a>
								</div>


							</div>
						</div>
					</div>
				</div>
			</div>
		</div><!-- ../section-row -->

	</section>

<?php $__env->stopSection(); ?>

<?php echo $__env->make('public.layouts.master', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>