<?php $__env->startSection('title', 'Healthcare Dashboard'); ?>


<?php $__env->startSection('content'); ?>
<div id="page">
	<!--==================================Header Open=================================-->
	<header class="">



	<div class="md-overlay"></div> <!-- Overlay for Popup -->
							<div id="menu">
								<?php echo $__env->make('public.layouts.headerMob', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
							</div>
		<div class="lp-menu-bar  lp-menu-bar-color">
			<div class="container">
					<div class="row">
					<?php echo $__env->make('public.layouts.logo', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>

					</div>
				</div>
		</div><!-- ../menu-bar -->
		<div class="page-heading listing-page archive-page ">
			<div class="page-heading-inner-container text-center">
				<h1>Healthcare Dashboard</h1>
				<ul class="breadcrumbs">
					<li><a href="/">Home</a></li>
					<li><span>Healthcare Dashboard</span></li>
				</ul>
			</div>
			<div class="page-header-overlay"></div>
		</div><!-- ../Home Search Container -->
	</header>
	<!--==================================Header Close=================================-->

	<!--==================================Section Open=================================-->
	<section class="aliceblue">
			<div class="dashboard-tabs">
				<div class="container">
					<!-- Nav tabs -->
					<ul class="nav nav-tabs" role="tablist">
						<li>
							<a href="/healthcare/dashboard" role="tab" data-toggle="tab">
								Your Bookings
							</a>
						</li>

						<li  class="active">
							<a href="#" role="tab" data-toggle="tab">
								Your Healthcare
							</a>
						</li>

						<li>
							<a href="/healthcare/settings" role="tab" data-toggle="tab">
								Account Settings
							</a>
						</li>
					</ul>
				</div>
			</div>
			<div class="container">
				<!-- Tab panes -->
				<div class="tab-content">
					<div class="tab-pane fade active in" id="dashborad">
						<div class="dashboard-tab">


							<div class="user-recent-listings-container">
									<div class="col-md-8"><h3 class="padding-top-35 padding-bottom-35">Your Healthcare</h3></div><div class="col-md-4"><div class="price-plan-button  pull-right">
									<a href="/logout" class="lp-secondary-btn btn-second-hover">Sign Out</a>
								</div></div><div class="user-recent-listings-inner">

										<div class="row">
						<div class="col-md-12">
							<div class="login-form-popup lp-border-radius-8">

								<div class="siginupcontainer page-signup">







									<form id="add-healthcare" class="form-horizontal margin-top-30" role="form" method="POST" action="<?php echo e(url('/register')); ?>" enctype='multipart/form-data'>
									<fieldset id="add-healthcare-form">
																 <?php echo e(csrf_field()); ?>

																 					<input type="hidden" name="healthcare_id" id="healthcare_id" value="<?php echo e($healthcare[0]['id']); ?>">
										<div class="form-group <?php echo e($errors->has('name') ? ' has-error' : ''); ?>">
											<label for="name">Name of Health care Provider *</label>
											<input type="text" class="form-control" name="name" id="name" value="<?php echo e($healthcare[0]['name']); ?>" required placeholder="Enter Health care Provider name">
											<?php if($errors->has('name')): ?>
												<span class="help-block">
													<strong><?php echo e($errors->first('name')); ?></strong>
												</span>
											<?php endif; ?>
										</div>
										<div class="form-group <?php echo e($errors->has('email') ? ' has-error' : ''); ?>">
											<label for="email">Email Address *</label>
											<input type="email" class="form-control healthcare-email" id="email" name="email" value="<?php echo e($healthcare[0]['email']); ?>" placeholder="Enter official email" required>
											 <?php if($errors->has('email')): ?>
												<span class="help-block">
													<strong><?php echo e($errors->first('email')); ?></strong>
												</span>
											<?php endif; ?>
										</div>

										<div class="form-group <?php echo e($errors->has('treatment_type') ? ' has-error' : ''); ?>">
											<label for="treatment_type">Type of Treatment available*</label>
											<?php $i = 1; ?>
											<?php foreach($selectedTypes as $sTypes): ?>

<select class="form-control treatment-type-<?php echo e($i); ?> margin-top-7" id="treatment_type_<?php echo e($i); ?>" name="treatment_type_<?php echo e($i); ?>" required>
<option value="<?php echo e($sTypes['id']); ?>"><?php echo e($sTypes['name']); ?></option>
										<?php foreach($types as $type): ?>
										<option value="<?php echo e($type['id']); ?>"><?php echo e($type['name']); ?></option>
										<?php endforeach; ?>
</select>
<?php $i++ ?>
<?php endforeach; ?>

<?php for($j = $i;$j <= count($types);$j++): ?>

											<select class="form-control treatment-type-<?php echo e($j); ?> margin-top-7 hide-type" id="treatment_type_<?php echo e($j); ?>" name="treatment_type_<?php echo e($j); ?>" required>
<option value="">Select your treatment type</option>
										<?php foreach($types as $type): ?>
										<option value="<?php echo e($type['id']); ?>"><?php echo e($type['name']); ?></option>
										<?php endforeach; ?>
</select>
<?php endfor; ?>
											<?php if($errors->has('treatment_type')): ?>
												<span class="help-block">
													<strong><?php echo e($errors->first('treatment_type')); ?></strong>
												</span>
											<?php endif; ?>
											<div class="add-type"><i class="fa fa-plus"></i> Add Type</div>
										</div>

										<div class="form-group <?php echo e($errors->has('twentyfourseven') ? ' has-error' : ''); ?>">
											<label for="twentyfourseven">Is your working hours 24 x 7?</label>
											<select  class="form-control" id="twentyfourseven" name="twentyfourseven">
											<option value="0">No</option>
										<option value="1" selected="">Yes</option>
										</select>
											<?php if($errors->has('twentyfourseven')): ?>
												<span class="help-block">
													<strong><?php echo e($errors->first('twentyfourseven')); ?></strong>
												</span>
											<?php endif; ?>
										</div>
									<div class="working-hours"  style="display:none">
											<div class="form-group  <?php echo e($errors->has('working_hours') ? ' has-error' : ''); ?>">
											<label for="working_hours">Working Hours ?</label>
									 </div>



										<div class="form-group <?php echo e($errors->has('working_hours_mon') ? ' has-error' : ''); ?>">
											 <div class="col-md-6 no-left-padding" ><select  class="form-control" disabled></div>
											 <option value="Monday to Saturday">Monday</option>
											 </select>
											 </div>
											 <div class="col-md-3"><select  class="form-control" name="working_hours_mon_from" id="working_hours_mon_from" required>
<option value="<?php echo e($healthcare[0]['mon_from']); ?>"><?php echo e($healthcare[0]['mon_from']); ?></option>
											 <option value="01 AM">01 AM</option>
											 <option value="02 AM">02 AM</option>
											 <option value="03 AM">03 AM</option>
											 <option value="04 AM">04 AM</option>
											 <option value="05 AM">05 AM</option>
											 <option value="06 AM">06 AM</option>
											 <option value="07 AM">07 AM</option>
											 <option value="08 AM">08 AM</option>
											 <option value="09 AM">09 AM</option>
											 <option value="10 AM">10 AM</option>
											 <option value="11 AM">11 AM</option>
											 <option value="12 PM">12 PM</option>
											 <option value="01 PM">01 PM</option>
											 <option value="02 PM">02 PM</option>
											 <option value="03 PM">03 PM</option>
											 <option value="04 PM">04 PM</option>
											 <option value="05 PM">05 PM</option>
											 <option value="06 PM">06 PM</option>
											 <option value="07 PM">07 PM</option>
											 <option value="08 PM">08 PM</option>
											 <option value="09 PM">09 PM</option>
											 <option value="10 PM">10 PM</option>
											 <option value="11 PM">11 PM</option>
											 <option value="12 AM">12 AM</option>
											 </select>
											 </div>
											 <div class="col-md-3 no-right-padding"><select  class="form-control"  name="working_hours_mon_to" id="working_hours_mon_to"  required>
<option value="<?php echo e($healthcare[0]['mon_to']); ?>"><?php echo e($healthcare[0]['mon_to']); ?></option>
											 <option value="01 AM">01 AM</option>
											 <option value="02 AM">02 AM</option>
											 <option value="03 AM">03 AM</option>
											 <option value="04 AM">04 AM</option>
											 <option value="05 AM">05 AM</option>
											 <option value="06 AM">06 AM</option>
											 <option value="07 AM">07 AM</option>
											 <option value="08 AM">08 AM</option>
											 <option value="09 AM">09 AM</option>
											 <option value="10 AM">10 AM</option>
											 <option value="11 AM">11 AM</option>
											 <option value="12 PM">12 PM</option>
											 <option value="01 PM">01 PM</option>
											 <option value="02 PM">02 PM</option>
											 <option value="03 PM">03 PM</option>
											 <option value="04 PM">04 PM</option>
											 <option value="05 PM">05 PM</option>
											 <option value="06 PM">06 PM</option>
											 <option value="07 PM">07 PM</option>
											 <option value="08 PM">08 PM</option>
											 <option value="09 PM">09 PM</option>
											 <option value="10 PM">10 PM</option>
											 <option value="11 PM">11 PM</option>
											 <option value="12 AM">12 AM</option></select>
											 </div>
											 <?php if($errors->has('working_hours_mon')): ?>
												 <span class="help-block">
													 <strong><?php echo e($errors->first('working_hours_mon')); ?></strong>
												 </span>
											 <?php endif; ?>
										 </div>

										 <div class="form-group <?php echo e($errors->has('working_hours_mon') ? ' has-error' : ''); ?>">
											 <div class="col-md-6 no-left-padding" ><select  disabled class="form-control"></div>
											 <option value="Monday to Saturday">Tuesday</option>
											 </select>
											 </div>
											 <div class="col-md-3"><select  class="form-control" name="working_hours_tue_from" id="working_hours_tue_from" required>
<option value="<?php echo e($healthcare[0]['true_from']); ?>"><?php echo e($healthcare[0]['tue_from']); ?></option>
											 <option value="01 AM">01 AM</option>
											 <option value="02 AM">02 AM</option>
											 <option value="03 AM">03 AM</option>
											 <option value="04 AM">04 AM</option>
											 <option value="05 AM">05 AM</option>
											 <option value="06 AM">06 AM</option>
											 <option value="07 AM">07 AM</option>
											 <option value="08 AM">08 AM</option>
											 <option value="09 AM">09 AM</option>
											 <option value="10 AM">10 AM</option>
											 <option value="11 AM">11 AM</option>
											 <option value="12 PM">12 PM</option>
											 <option value="01 PM">01 PM</option>
											 <option value="02 PM">02 PM</option>
											 <option value="03 PM">03 PM</option>
											 <option value="04 PM">04 PM</option>
											 <option value="05 PM">05 PM</option>
											 <option value="06 PM">06 PM</option>
											 <option value="07 PM">07 PM</option>
											 <option value="08 PM">08 PM</option>
											 <option value="09 PM">09 PM</option>
											 <option value="10 PM">10 PM</option>
											 <option value="11 PM">11 PM</option>
											 <option value="12 AM">12 AM</option>
											 </select>
											 </div>
											 <div class="col-md-3 no-right-padding"><select   class="form-control" name="working_hours_tue_to" id="working_hours_tue_to"  required>
<option value="<?php echo e($healthcare[0]['tue_to']); ?>"><?php echo e($healthcare[0]['tue_to']); ?></option>
											 <option value="01 AM">01 AM</option>
											 <option value="02 AM">02 AM</option>
											 <option value="03 AM">03 AM</option>
											 <option value="04 AM">04 AM</option>
											 <option value="05 AM">05 AM</option>
											 <option value="06 AM">06 AM</option>
											 <option value="07 AM">07 AM</option>
											 <option value="08 AM">08 AM</option>
											 <option value="09 AM">09 AM</option>
											 <option value="10 AM">10 AM</option>
											 <option value="11 AM">11 AM</option>
											 <option value="12 PM">12 PM</option>
											 <option value="01 PM">01 PM</option>
											 <option value="02 PM">02 PM</option>
											 <option value="03 PM">03 PM</option>
											 <option value="04 PM">04 PM</option>
											 <option value="05 PM">05 PM</option>
											 <option value="06 PM">06 PM</option>
											 <option value="07 PM">07 PM</option>
											 <option value="08 PM">08 PM</option>
											 <option value="09 PM">09 PM</option>
											 <option value="10 PM">10 PM</option>
											 <option value="11 PM">11 PM</option>
											 <option value="12 AM">12 AM</option></select>
											 </div>
											 <?php if($errors->has('working_hours_mon')): ?>
												 <span class="help-block">
													 <strong><?php echo e($errors->first('working_hours_mon')); ?></strong>
												 </span>
											 <?php endif; ?>
										 </div>

										 <div class="form-group <?php echo e($errors->has('working_hours_mon') ? ' has-error' : ''); ?>">
											 <div class="col-md-6 no-left-padding" ><select  disabled class="form-control"></div>
											 <option value="Monday to Saturday">Wednesday</option>
											 </select>
											 </div>
											 <div class="col-md-3"><select  class="form-control" name="working_hours_wed_from" id="working_hours_wed_from" required>
<option value="<?php echo e($healthcare[0]['wed_from']); ?>"><?php echo e($healthcare[0]['wed_from']); ?></option>
											 <option value="01 AM">01 AM</option>
											 <option value="02 AM">02 AM</option>
											 <option value="03 AM">03 AM</option>
											 <option value="04 AM">04 AM</option>
											 <option value="05 AM">05 AM</option>
											 <option value="06 AM">06 AM</option>
											 <option value="07 AM">07 AM</option>
											 <option value="08 AM">08 AM</option>
											 <option value="09 AM">09 AM</option>
											 <option value="10 AM">10 AM</option>
											 <option value="11 AM">11 AM</option>
											 <option value="12 PM">12 PM</option>
											 <option value="01 PM">01 PM</option>
											 <option value="02 PM">02 PM</option>
											 <option value="03 PM">03 PM</option>
											 <option value="04 PM">04 PM</option>
											 <option value="05 PM">05 PM</option>
											 <option value="06 PM">06 PM</option>
											 <option value="07 PM">07 PM</option>
											 <option value="08 PM">08 PM</option>
											 <option value="09 PM">09 PM</option>
											 <option value="10 PM">10 PM</option>
											 <option value="11 PM">11 PM</option>
											 <option value="12 AM">12 AM</option>
											 </select>
											 </div>
											 <div class="col-md-3 no-right-padding"><select   class="form-control" name="working_hours_wed_to" id="working_hours_wed_to"  required>
<option value="<?php echo e($healthcare[0]['wed_to']); ?>"><?php echo e($healthcare[0]['wed_to']); ?></option>
											 <option value="01 AM">01 AM</option>
											 <option value="02 AM">02 AM</option>
											 <option value="03 AM">03 AM</option>
											 <option value="04 AM">04 AM</option>
											 <option value="05 AM">05 AM</option>
											 <option value="06 AM">06 AM</option>
											 <option value="07 AM">07 AM</option>
											 <option value="08 AM">08 AM</option>
											 <option value="09 AM">09 AM</option>
											 <option value="10 AM">10 AM</option>
											 <option value="11 AM">11 AM</option>
											 <option value="12 PM">12 PM</option>
											 <option value="01 PM">01 PM</option>
											 <option value="02 PM">02 PM</option>
											 <option value="03 PM">03 PM</option>
											 <option value="04 PM">04 PM</option>
											 <option value="05 PM">05 PM</option>
											 <option value="06 PM">06 PM</option>
											 <option value="07 PM">07 PM</option>
											 <option value="08 PM">08 PM</option>
											 <option value="09 PM">09 PM</option>
											 <option value="10 PM">10 PM</option>
											 <option value="11 PM">11 PM</option>
											 <option value="12 AM">12 AM</option></select>
											 </div>
											 <?php if($errors->has('working_hours_mon')): ?>
												 <span class="help-block">
													 <strong><?php echo e($errors->first('working_hours_mon')); ?></strong>
												 </span>
											 <?php endif; ?>
										 </div>

										 <div class="form-group <?php echo e($errors->has('working_hours_mon') ? ' has-error' : ''); ?>">
											 <div class="col-md-6 no-left-padding" ><select  disabled class="form-control"></div>
											 <option value="Monday to Saturday">Thursday</option>
											 </select>
											 </div>
											 <div class="col-md-3"><select  class="form-control" name="working_hours_thu_from" id="working_hours_thu_from" required>
											 <option value="<?php echo e($healthcare[0]['thu_from']); ?>"><?php echo e($healthcare[0]['thu_from']); ?></option>
											 <option value="01 AM">01 AM</option>
											 <option value="02 AM">02 AM</option>
											 <option value="03 AM">03 AM</option>
											 <option value="04 AM">04 AM</option>
											 <option value="05 AM">05 AM</option>
											 <option value="06 AM">06 AM</option>
											 <option value="07 AM">07 AM</option>
											 <option value="08 AM">08 AM</option>
											 <option value="09 AM">09 AM</option>
											 <option value="10 AM">10 AM</option>
											 <option value="11 AM">11 AM</option>
											 <option value="12 PM">12 PM</option>
											 <option value="01 PM">01 PM</option>
											 <option value="02 PM">02 PM</option>
											 <option value="03 PM">03 PM</option>
											 <option value="04 PM">04 PM</option>
											 <option value="05 PM">05 PM</option>
											 <option value="06 PM">06 PM</option>
											 <option value="07 PM">07 PM</option>
											 <option value="08 PM">08 PM</option>
											 <option value="09 PM">09 PM</option>
											 <option value="10 PM">10 PM</option>
											 <option value="11 PM">11 PM</option>
											 <option value="12 AM">12 AM</option>
											 </select>
											 </div>
											 <div class="col-md-3 no-right-padding"><select  class="form-control" name="working_hours_thu_to" id="working_hours_thu_to"  required>
<option value="<?php echo e($healthcare[0]['thu_to']); ?>"><?php echo e($healthcare[0]['thu_to']); ?></option>
											 <option value="01 AM">01 AM</option>
											 <option value="02 AM">02 AM</option>
											 <option value="03 AM">03 AM</option>
											 <option value="04 AM">04 AM</option>
											 <option value="05 AM">05 AM</option>
											 <option value="06 AM">06 AM</option>
											 <option value="07 AM">07 AM</option>
											 <option value="08 AM">08 AM</option>
											 <option value="09 AM">09 AM</option>
											 <option value="10 AM">10 AM</option>
											 <option value="11 AM">11 AM</option>
											 <option value="12 PM">12 PM</option>
											 <option value="01 PM">01 PM</option>
											 <option value="02 PM">02 PM</option>
											 <option value="03 PM">03 PM</option>
											 <option value="04 PM">04 PM</option>
											 <option value="05 PM">05 PM</option>
											 <option value="06 PM">06 PM</option>
											 <option value="07 PM">07 PM</option>
											 <option value="08 PM">08 PM</option>
											 <option value="09 PM">09 PM</option>
											 <option value="10 PM">10 PM</option>
											 <option value="11 PM">11 PM</option>
											 <option value="12 AM">12 AM</option></select>
											 </div>
											 <?php if($errors->has('working_hours_mon')): ?>
												 <span class="help-block">
													 <strong><?php echo e($errors->first('working_hours_mon')); ?></strong>
												 </span>
											 <?php endif; ?>
										 </div>

										 <div class="form-group <?php echo e($errors->has('working_hours_mon') ? ' has-error' : ''); ?>">
											 <div class="col-md-6 no-left-padding" ><select  disabled class="form-control"></div>
											 <option value="Monday to Saturday">Friday</option>
											 </select>
											 </div>
											 <div class="col-md-3"><select  class="form-control" name="working_hours_fri_from" id="working_hours_fri_from" required>
											 <option value="<?php echo e($healthcare[0]['fri_from']); ?>"><?php echo e($healthcare[0]['fri_from']); ?></option>
											 <option value="01 AM">01 AM</option>
											 <option value="02 AM">02 AM</option>
											 <option value="03 AM">03 AM</option>
											 <option value="04 AM">04 AM</option>
											 <option value="05 AM">05 AM</option>
											 <option value="06 AM">06 AM</option>
											 <option value="07 AM">07 AM</option>
											 <option value="08 AM">08 AM</option>
											 <option value="09 AM">09 AM</option>
											 <option value="10 AM">10 AM</option>
											 <option value="11 AM">11 AM</option>
											 <option value="12 PM">12 PM</option>
											 <option value="01 PM">01 PM</option>
											 <option value="02 PM">02 PM</option>
											 <option value="03 PM">03 PM</option>
											 <option value="04 PM">04 PM</option>
											 <option value="05 PM">05 PM</option>
											 <option value="06 PM">06 PM</option>
											 <option value="07 PM">07 PM</option>
											 <option value="08 PM">08 PM</option>
											 <option value="09 PM">09 PM</option>
											 <option value="10 PM">10 PM</option>
											 <option value="11 PM">11 PM</option>
											 <option value="12 AM">12 AM</option>
											 </select>
											 </div>
											 <div class="col-md-3 no-right-padding"><select  class="form-control" name="working_hours_fri_to" id="working_hours_fri_to"  required>
											 <option value="<?php echo e($healthcare[0]['fri_to']); ?>"><?php echo e($healthcare[0]['fri_to']); ?></option>
											 <option value="01 AM">01 AM</option>
											 <option value="02 AM">02 AM</option>
											 <option value="03 AM">03 AM</option>
											 <option value="04 AM">04 AM</option>
											 <option value="05 AM">05 AM</option>
											 <option value="06 AM">06 AM</option>
											 <option value="07 AM">07 AM</option>
											 <option value="08 AM">08 AM</option>
											 <option value="09 AM">09 AM</option>
											 <option value="10 AM">10 AM</option>
											 <option value="11 AM">11 AM</option>
											 <option value="12 PM">12 PM</option>
											 <option value="01 PM">01 PM</option>
											 <option value="02 PM">02 PM</option>
											 <option value="03 PM">03 PM</option>
											 <option value="04 PM">04 PM</option>
											 <option value="05 PM">05 PM</option>
											 <option value="06 PM">06 PM</option>
											 <option value="07 PM">07 PM</option>
											 <option value="08 PM">08 PM</option>
											 <option value="09 PM">09 PM</option>
											 <option value="10 PM">10 PM</option>
											 <option value="11 PM">11 PM</option>
											 <option value="12 AM">12 AM</option></select>
											 </div>
											 <?php if($errors->has('working_hours_mon')): ?>
												 <span class="help-block">
													 <strong><?php echo e($errors->first('working_hours_mon')); ?></strong>
												 </span>
											 <?php endif; ?>
										 </div>

										 <div class="form-group <?php echo e($errors->has('working_hours_mon') ? ' has-error' : ''); ?>">
											 <div class="col-md-6 no-left-padding" ><select  disabled class="form-control"></div>
											 <option value="Monday to Saturday">Saturday</option>
											 </select>
											 </div>
											 <div class="col-md-3"><select  class="form-control" name="working_hours_sat_from" id="working_hours_sat_from" required>
											 <option value="<?php echo e($healthcare[0]['sat_from']); ?>"><?php echo e($healthcare[0]['sat_from']); ?></option>
											 <option value="01 AM">01 AM</option>
											 <option value="02 AM">02 AM</option>
											 <option value="03 AM">03 AM</option>
											 <option value="04 AM">04 AM</option>
											 <option value="05 AM">05 AM</option>
											 <option value="06 AM">06 AM</option>
											 <option value="07 AM">07 AM</option>
											 <option value="08 AM">08 AM</option>
											 <option value="09 AM">09 AM</option>
											 <option value="10 AM">10 AM</option>
											 <option value="11 AM">11 AM</option>
											 <option value="12 PM">12 PM</option>
											 <option value="01 PM">01 PM</option>
											 <option value="02 PM">02 PM</option>
											 <option value="03 PM">03 PM</option>
											 <option value="04 PM">04 PM</option>
											 <option value="05 PM">05 PM</option>
											 <option value="06 PM">06 PM</option>
											 <option value="07 PM">07 PM</option>
											 <option value="08 PM">08 PM</option>
											 <option value="09 PM">09 PM</option>
											 <option value="10 PM">10 PM</option>
											 <option value="11 PM">11 PM</option>
											 <option value="12 AM">12 AM</option>
											 </select>
											 </div>
											 <div class="col-md-3 no-right-padding"><select  class="form-control" name="working_hours_sat_to" id="working_hours_sat_to"  required>
											 <option value="<?php echo e($healthcare[0]['sat_to']); ?>"><?php echo e($healthcare[0]['sat_to']); ?></option>
											 <option value="01 AM">01 AM</option>
											 <option value="02 AM">02 AM</option>
											 <option value="03 AM">03 AM</option>
											 <option value="04 AM">04 AM</option>
											 <option value="05 AM">05 AM</option>
											 <option value="06 AM">06 AM</option>
											 <option value="07 AM">07 AM</option>
											 <option value="08 AM">08 AM</option>
											 <option value="09 AM">09 AM</option>
											 <option value="10 AM">10 AM</option>
											 <option value="11 AM">11 AM</option>
											 <option value="12 PM">12 PM</option>
											 <option value="01 PM">01 PM</option>
											 <option value="02 PM">02 PM</option>
											 <option value="03 PM">03 PM</option>
											 <option value="04 PM">04 PM</option>
											 <option value="05 PM">05 PM</option>
											 <option value="06 PM">06 PM</option>
											 <option value="07 PM">07 PM</option>
											 <option value="08 PM">08 PM</option>
											 <option value="09 PM">09 PM</option>
											 <option value="10 PM">10 PM</option>
											 <option value="11 PM">11 PM</option>
											 <option value="12 AM">12 AM</option></select>
											 </div>
											 <?php if($errors->has('working_hours_mon')): ?>
												 <span class="help-block">
													 <strong><?php echo e($errors->first('working_hours_mon')); ?></strong>
												 </span>
											 <?php endif; ?>
										 </div>


										<div class="form-group <?php echo e($errors->has('working_hours_sun') ? ' has-error' : ''); ?>">
											<div class="col-md-6 no-left-padding" ><select disabled class="form-control"></div>
											<option value="Sunday">Sunday</option>
											</select>
											</div>
											<div class="col-md-3"><select  class="form-control" name="working_hours_sun_from" id="working_hours_sun_from"   required>
											<option value="<?php echo e($healthcare[0]['sun_from']); ?>"><?php echo e($healthcare[0]['sun_from']); ?></option>
											<option value="01 AM">01 AM</option>
											<option value="02 AM">02 AM</option>
											<option value="03 AM">03 AM</option>
											<option value="04 AM">04 AM</option>
											<option value="05 AM">05 AM</option>
											<option value="06 AM">06 AM</option>
											<option value="07 AM">07 AM</option>
											<option value="08 AM">08 AM</option>
											<option value="09 AM">09 AM</option>
											<option value="10 AM">10 AM</option>
											<option value="11 AM">11 AM</option>
											<option value="12 PM">12 PM</option>
											<option value="01 PM">01 PM</option>
											<option value="02 PM">02 PM</option>
											<option value="03 PM">03 PM</option>
											<option value="04 PM">04 PM</option>
											<option value="05 PM">05 PM</option>
											<option value="06 PM">06 PM</option>
											<option value="07 PM">07 PM</option>
											<option value="08 PM">08 PM</option>
											<option value="09 PM">09 PM</option>
											<option value="10 PM">10 PM</option>
											<option value="11 PM">11 PM</option>
											<option value="12 AM">12 AM</option>
											</select>
											</div>
											<div class="col-md-3 no-right-padding"><select  class="form-control" name="working_hours_sun_to" id="working_hours_sun_to"   required>
<option value="<?php echo e($healthcare[0]['sun_to']); ?>"><?php echo e($healthcare[0]['sun_to']); ?></option>
											<option value="01 AM">01 AM</option>
											<option value="02 AM">02 AM</option>
											<option value="03 AM">03 AM</option>
											<option value="04 AM">04 AM</option>
											<option value="05 AM">05 AM</option>
											<option value="06 AM">06 AM</option>
											<option value="07 AM">07 AM</option>
											<option value="08 AM">08 AM</option>
											<option value="09 AM">09 AM</option>
											<option value="10 AM">10 AM</option>
											<option value="11 AM">11 AM</option>
											<option value="12 PM">12 PM</option>
											<option value="01 PM">01 PM</option>
											<option value="02 PM">02 PM</option>
											<option value="03 PM">03 PM</option>
											<option value="04 PM">04 PM</option>
											<option value="05 PM">05 PM</option>
											<option value="06 PM">06 PM</option>
											<option value="07 PM">07 PM</option>
											<option value="08 PM">08 PM</option>
											<option value="09 PM">09 PM</option>
											<option value="10 PM">10 PM</option>
											<option value="11 PM">11 PM</option>
											<option value="12 AM">12 AM</option></select>
											</div>
											<?php if($errors->has('working_hours_sun')): ?>
												<span class="help-block">
													<strong><?php echo e($errors->first('working_hours_sun')); ?></strong>
												</span>
											<?php endif; ?>
										</div>
									</div>
										<div class="form-group <?php echo e($errors->has('certificate') ? ' has-error' : ''); ?>">
											<label for="certificate">Do you have certification ?</label>
											<select  class="form-control" id="certificate" name="certificate">
												<?php if($healthcare[0]['certificate'] == 1): ?>
												<option value="1">Yes</option>
												<option value="0">No</option>
												<?php else: ?>
												<option value="0">No</option>
												<option value="1">Yes</option>
												<?php endif; ?>
									</select>
											<?php if($errors->has('certificate')): ?>
												<span class="help-block">
													<strong><?php echo e($errors->first('certificate')); ?></strong>
												</span>
											<?php endif; ?>
										</div>


										<div class="form-group <?php echo e($errors->has('accreditation') ? ' has-error' : ''); ?>">
											<label for="accreditation">Accreditation</label> <br>
											<label for="nabh" class="fecilities-lbl"><input type="checkbox" id="nabh" name="nabh" value="1" class="fecilites-check"> NABH</label>
											<label for="iso" class="fecilities-lbl"><input type="checkbox" id="iso"  value="1" name="iso" class="fecilites-check"> ISO</label>
									<label for="ohsas" class="fecilities-lbl"><input type="checkbox" id="ohsas" value="1" name="ohsas" class="fecilites-check"> OHSAS</label>
									<label for="jci" class="fecilities-lbl"><input type="checkbox" id="jci" value="1" name="jci" class="fecilites-check"> JCI</label>
									<label for="nabl" class="fecilities-lbl"><input type="checkbox" id="nabl" value="1" name="nabl" class="fecilites-check"> NABL</label>
										</div>

										<div class="form-group <?php echo e($errors->has('departments') ? ' has-error' : ''); ?>">
											<label for="departments">Departments / Services * </label>
											<input type="text" class="form-control" id="departments" name="departments" value="<?php echo e(old('departments')); ?>" placeholder="Enter departments" required>
											 <?php if($errors->has('departments')): ?>
												<span class="help-block">
													<strong><?php echo e($errors->first('departments')); ?></strong>
												</span>
											<?php endif; ?>
										</div>

										<div class="form-group <?php echo e($errors->has('country') ? ' has-error' : ''); ?>"   required>
											<label for="country">Country *</label>
											<select  class="form-control" id="country" name="country">
									<option value="101">India</option>
									</select>
											<?php if($errors->has('country')): ?>
												<span class="help-block">
													<strong><?php echo e($errors->first('country')); ?></strong>
												</span>
											<?php endif; ?>
										</div>
										<div class="form-group <?php echo e($errors->has('state') ? ' has-error' : ''); ?>"   required>
											<label for="state">State *</label>
											<select class="form-control" id="state" name="state">
									<option value="19">Kerala</option>
									</select>
											<?php if($errors->has('state')): ?>
												<span class="help-block">
													<strong><?php echo e($errors->first('state')); ?></strong>
												</span>
											<?php endif; ?>
										</div>
										<div class="form-group <?php echo e($errors->has('city') ? ' has-error' : ''); ?>"   required>
											<label for="city">City *</label>
											<select class="form-control" id="city" name="city">
									<option value="1947">Kozhikode</option>
									</select>
											<?php if($errors->has('city')): ?>
												<span class="help-block">
													<strong><?php echo e($errors->first('country')); ?></strong>
												</span>
											<?php endif; ?>
										</div>
										<div class="form-group <?php echo e($errors->has('area') ? ' has-error' : ''); ?>"   required>
											<label for="area">Town / Village *</label>
											<input type="text" class="form-control" name="area" id="area"  value="<?php echo e(old('area')); ?>" placeholder="Enter town / village" ></input>

											<?php if($errors->has('area')): ?>
												<span class="help-block">
													<strong><?php echo e($errors->first('area')); ?></strong>
												</span>
											<?php endif; ?>
										</div>
										<div class="form-group <?php echo e($errors->has('address') ? ' has-error' : ''); ?>">
											<label for="address">Address </label>
											<textarea class="form-control" name="address" id="address" placeholder="Enter your healthcare center address" ><?php echo e(old('address')); ?></textarea>
											<?php if($errors->has('address')): ?>
												<span class="help-block">
													<strong><?php echo e($errors->first('address')); ?></strong>
												</span>
											<?php endif; ?>
										</div>
										<div class="form-group <?php echo e($errors->has('pin') ? ' has-error' : ''); ?>">
											<label for="pin">Pin </label>
											<input type="number" class="form-control" min="0" name="pin" id="pin"  value="<?php echo e(old('pin')); ?>" placeholder="Enter health center Pin code" onkeypress='return event.charCode >= 48 && event.charCode <= 57'></input>
											<?php if($errors->has('pin')): ?>
												<span class="help-block">
													<strong><?php echo e($errors->first('pin')); ?></strong>
												</span>
											<?php endif; ?>
										</div>
										<div class="form-group <?php echo e($errors->has('contact_name') ? ' has-error' : ''); ?>">
											<label for="contact_name">Contact Person Name </label>
											<input type="text" class="form-control" name="contact_name" required id="contact_name" placeholder="Enter contact person name" value="<?php echo e(old('contact_name')); ?>">
											<?php if($errors->has('contact_name')): ?>
												<span class="help-block">
													<strong><?php echo e($errors->first('contact_name')); ?></strong>
												</span>
											<?php endif; ?>
										</div>
										<div class="form-group <?php echo e($errors->has('contact_email') ? ' has-error' : ''); ?>">
											<label for="contact_email">Contact Person Email </label>
											<input type="text" class="form-control" name="contact_email" required id="contact_email" placeholder="Enter contact person email" value="<?php echo e(old('contact_email')); ?>">
											<?php if($errors->has('contact_email')): ?>
												<span class="help-block">
													<strong><?php echo e($errors->first('contact_email')); ?></strong>
												</span>
											<?php endif; ?>
										</div>
										<div class="form-group  padding-left-0  <?php echo e($errors->has('mobile') ? ' has-error' : ''); ?>">
											<label for="mobile">Mobile Number *</label>
											<div class="col-md-3" style="
									padding-top: 30px;
									padding-left: 0px;
									"><select class="form-control" id="country_code_mobile" name="country_code_mobile" >
									<option value="91">+91 (IND)</option>
									<option value="974">+974 (QAT)</option>
									<option value="971">+971 (UAE)</option>
									<option value="966">+966 (KSA)</option>
									<option value="968">+968 (OMA)</option>
									<option value="965">+965 (KWT)</option>
									<option value="973">+973 (BAH)</option>

									</select></div><div class="col-md-9" style="
									padding-left: 0px; padding-right: 0px;
									">
									<input type="number" min="0" class="form-control" id="mobile" placeholder="Enter health care mobile number" name="mobile" value="<?php echo e(old('mobile')); ?>" required> </div>
											 <?php if($errors->has('mobile')): ?>
												<span class="help-block">
													<strong><?php echo e($errors->first('mobile')); ?></strong>
												</span>
											<?php endif; ?>
										</div>
										<div class="form-group <?php echo e($errors->has('phone') ? ' has-error' : ''); ?>">
											<label for="phone">Phone</label>
											<div class="col-md-3" style="
									padding-top: 30px;
									padding-left: 0px;
									"><select class="form-control" id="country_code_phone" name="country_code_phone">
									<option value="91">+91 (IND)</option>
									<option value="974">+974 (QAT)</option>
									<option value="971">+971 (UAE)</option>
									<option value="966">+966 (KSA)</option>
									<option value="968">+968 (OMA)</option>
									<option value="965">+965 (KWT)</option>
									<option value="973">+973 (BAH)</option>

									</select></div><div class="col-md-9" style="
									padding-left: 0px; padding-right: 0px;
									">
											<input type="number" min="0"  class="form-control" name="phone" required id="phone" placeholder="Enter health center phone number" value="<?php echo e(old('phone')); ?>" onkeypress='return event.charCode >= 48 && event.charCode <= 57'></input>
											<?php if($errors->has('phone')): ?>
												<span class="help-block">
													<strong><?php echo e($errors->first('phone')); ?></strong>
												</span>
											<?php endif; ?>
										</div>
										</div>
										<div class="form-group <?php echo e($errors->has('fax') ? ' has-error' : ''); ?>">
											<label for="fax">Fax</label>
											<div class="col-md-3" style="
									padding-top: 30px;
									padding-left: 0px;
									"><select class="form-control" id="country_code_fax" name="country_code_fax">
									<option value="91">+91 (IND)</option>
									<option value="974">+974 (QAT)</option>
									<option value="971">+971 (UAE)</option>
									<option value="966">+966 (KSA)</option>
									<option value="968">+968 (OMA)</option>
									<option value="965">+965 (KWT)</option>
									<option value="973">+973 (BAH)</option>

									</select></div><div class="col-md-9" style="
									padding-left: 0px; padding-right: 0px;
									">
											<input  type="number" min="0" class="form-control" name="fax"  id="fax" value="<?php echo e(old('fax')); ?>" placeholder="Enter Health center fax">
											<?php if($errors->has('fax')): ?>
												<span class="help-block">
													<strong><?php echo e($errors->first('fax')); ?></strong>
												</span>
											<?php endif; ?>
										</div></div>
										<div class="form-group <?php echo e($errors->has('website') ? ' has-error' : ''); ?>">
											<label for="website">Website</label>
											<input type="text" class="form-control" name="website"  id="website" value="<?php echo e(old('website')); ?>" placeholder="Enter Health center website address">
											<?php if($errors->has('website')): ?>
												<span class="help-block">
													<strong><?php echo e($errors->first('website')); ?></strong>
												</span>
											<?php endif; ?>
										</div>

										<div class="form-group <?php echo e($errors->has('description') ? ' has-error' : ''); ?>">
											<label for="description">Describe your health care *</label>
											<textarea class="form-control" name="description" required id="description" placeholder="Tell us more about your health centre (less than 200 words)"><?php echo e(old('description')); ?></textarea>
											<?php if($errors->has('description')): ?>
												<span class="help-block">
													<strong><?php echo e($errors->first('description')); ?></strong>
												</span>
											<?php endif; ?>
										</div>

										<div class="form-group <?php echo e($errors->has('fecilities') ? ' has-error' : ''); ?>">
											<label for="fecilities">Available services and facilities</label> <br>
											<label for="fec-lab" class="fecilities-lbl"><input type="checkbox" id="fec-lab" name="fec-lab" class="fecilites-check" value="1" <?php if($healthcare[0]['lab'] == 1): ?> checked <?php endif; ?>> Lab</label>
											<label for="fec-parking" class="fecilities-lbl"><input type="checkbox" id="fec-parking" name="fec-parking" class="fecilites-check" value="1" <?php if($healthcare[0]['parking'] == 1): ?> checked <?php endif; ?>> Parking</label>
											<label for="fec-pharmacy" class="fecilities-lbl"><input type="checkbox" id="fec-pharmacy" name="fec-pharmacy" class="fecilites-check" value="1" <?php if($healthcare[0]['pharmacy'] == 1): ?> checked <?php endif; ?>> Pharmacy</label>
											<label for="fec-wheelchair" class="fecilities-lbl"><input type="checkbox" id="fec-wheelchair" name="fec-wheelchair" class="fecilites-check" value="1" <?php if($healthcare[0]['wheelchair'] == 1): ?> checked <?php endif; ?>> Wheelchair Access</label>
											<label for="fec-ambulance" class="fecilities-lbl"><input type="checkbox" id="fec-ambulance" name="fec-ambulance" class="fecilites-check" value="1" <?php if($healthcare[0]['ambulance'] == 1): ?> checked <?php endif; ?>> Ambulance</label>
											<label for="fec-inpatient" class="fecilities-lbl"><input type="checkbox" id="fec-inpatient" name="fec-inpatient" class="fecilites-check" value="1" <?php if($healthcare[0]['inpatient'] == 1): ?> checked <?php endif; ?>> Inpatient</label>
											<label for="fec-bloodbank" class="fecilities-lbl"><input type="checkbox" id="fec-bloodbank" name="fec-bloodbank" class="fecilites-check" value="1" <?php if($healthcare[0]['bloodbank'] == 1): ?> checked <?php endif; ?>> Blood Bank</label>
											<label for="fec-fitnesscentre" class="fecilities-lbl"><input type="checkbox" id="fec-fitnesscentre" name="fec-fitnesscentre" class="fecilites-check" value="1" <?php if($healthcare[0]['fitness'] == 1): ?> checked <?php endif; ?>> Fitness Centre</label>
											<label for="fec-canteen" class="fecilities-lbl"><input type="checkbox" id="fec-canteen" name="fec-canteen" class="fecilites-check" value="1" <?php if($healthcare[0]['canteen'] == 1): ?> checked <?php endif; ?>> Food/Canteen</label>
											<label for="fec-insurance" class="fecilities-lbl"><input type="checkbox" id="fec-insurance" name="fec-insurance" class="fecilites-check" value="1" <?php if($healthcare[0]['insurance'] == 1): ?> checked <?php endif; ?>> Insurance</label>


											</div>

										<div class="form-group <?php echo e($errors->has('other_fecilities') ? ' has-error' : ''); ?>">
											<label for="other_fecilities">Any other facilities available?</label>
											<input type="text" class="form-control" name="other_fecilities"  id="other_fecilities" value="<?php echo e($healthcare[0]['other_fecilities']); ?>" placeholder="Enter Other facilities avilable">

											<?php if($errors->has('other_fecilities')): ?>
												<span class="help-block">
													<strong><?php echo e($errors->first('other_fecilities')); ?></strong>
												</span>
											<?php endif; ?>
										</div>


										<div class="form-group <?php echo e($errors->has('payment') ? ' has-error' : ''); ?>">
											<label for="payment">Payment Modes</label> <br>
											<label for="pay-cash" class="fecilities-lbl"><input type="checkbox" id="pay-cash" name="pay-cash" value="1" class="fecilites-check" <?php if($healthcare[0]['cash'] == 1): ?> checked <?php endif; ?>> Cash</label>
											<label for="pay-creditcard" class="fecilities-lbl"><input type="checkbox" id="pay-creditcard"  value="1" name="pay-creditcard" class="fecilites-check" <?php if($healthcare[0]['credit_card'] == 1): ?> checked <?php endif; ?>> Credit Card</label>
									<label for="pay-debitcard" class="fecilities-lbl"><input type="checkbox" id="pay-debitcard" value="1" name="pay-debitcard" class="fecilites-check" <?php if($healthcare[0]['debit_card'] == 1): ?> checked <?php endif; ?>> Debit Card</label>
									<label for="pay-cheque" class="fecilities-lbl"><input type="checkbox" id="pay-cheque" value="1" name="pay-cheque" class="fecilites-check" <?php if($healthcare[0]['cheque'] == 1): ?> checked <?php endif; ?>> Cheque</label>
												</div>

										<div class="col-md-6" style="padding-left:0px;">
										<div class="form-group <?php echo e($errors->has('no_of_beds') ? ' has-error' : ''); ?>">
											<label for="no_of_beds">Number of beds </label>
											<input type="number" min="0"  class="form-control" id="no_of_beds" name="no_of_beds" value="<?php echo e($healthcare[0]['no_of_beds']); ?>" placeholder="Enter No of beds">
											 <?php if($errors->has('no_of_beds')): ?>
												<span class="help-block">
													<strong><?php echo e($errors->first('no_of_beds')); ?></strong>
												</span>
											<?php endif; ?>
										</div></div><div class="col-md-6" style="padding-right:0px;padding-left:30px">
											<div class="form-group <?php echo e($errors->has('bed_range') ? ' has-error' : ''); ?>">
												<label for="bed_range">Bed range</label>
												<select  class="form-control" id="bed_range" name="bed_range">

											<option value="<?php echo e($healthcare[0]['bed_range']); ?>" data-from="0" data-to="50"><?php echo e($healthcare[0]['bed_range']); ?></option>
											<option value="0-50" data-from="0" data-to="50">0-50</option>
											<option value="51-100" data-from="51" data-to="100">51-100</option>
											<option value="101-200" data-from="101" data-to="200">101-200</option>
											<option value="201-300" data-from="201" data-to="+">201-300</option>
											<option value="300+" data-from="0" data-to="50">300+</option>
											</select>
												<?php if($errors->has('bed_range')): ?>
													<span class="help-block">
														<strong><?php echo e($errors->first('bed_range')); ?></strong>
													</span>
												<?php endif; ?>
											</div>
									</div>

										<div class="form-group <?php echo e($errors->has('food_types') ? ' has-error' : ''); ?> food-type">
											<label for="food_types">Type of Foods</label> <br>
											<label for="food_veg" class="fecilities-lbl"><input type="checkbox" value="1" id="food_veg" name="food_veg" class="fecilites-check" <?php if($healthcare[0]['food_veg'] == 1): ?> checked <?php endif; ?>> Veg</label>
											<label for="food_non_veg" class="fecilities-lbl"><input type="checkbox" value="1" id="food_non_veg" name="food_non_veg" class="fecilites-check" <?php if($healthcare[0]['food_non_veg'] == 1): ?> checked <?php endif; ?>> Non Veg</label>
									<label for="food_organic" class="fecilities-lbl"><input type="checkbox" value="1" id="food_organic" name="food_organic" class="fecilites-check" <?php if($healthcare[0]['food_organic'] == 1): ?> checked <?php endif; ?>> Organic Food</label>
									<label for="food_personalised" class="fecilities-lbl"><input type="checkbox" value="1" id="food_personalised" name="food_personalised" class="fecilites-check" <?php if($healthcare[0]['food_personalised'] == 1): ?> checked <?php endif; ?>> Personalised Diet</label>
										</div>
										<div class="form-group <?php echo e($errors->has('category') ? ' has-error' : ''); ?>">
											<label for="category">Select Health Care Provider category</label>
											<select  class="form-control" id="category" name="category" required>
												<option value="<?php echo e($healthcare[0]['price']); ?>"><?php if($healthcare[0]['price'] == 1): ?> Clinic <?php endif; ?> <?php if($healthcare[0]['price'] == 2): ?> Mini Hospital <?php endif; ?> <?php if($healthcare[0]['price'] == 3): ?> Hospital / General <?php endif; ?> <?php if($healthcare[0]['price'] == 4): ?> Speciality <?php endif; ?> <?php if($healthcare[0]['price'] == 5): ?> Multi Speciality <?php endif; ?></option>

												<option value="1">Clinic</option>
												<option value="2">Mini Hospital</option>
												<option value="3">Hospital / General</option>
												<option value="4">Speciality</option>
												<option value="5">Multi Speciality</option>

											</select>
											<?php if($errors->has('category')): ?>
												<span class="help-block">
													<strong><?php echo e($errors->first('category')); ?></strong>
												</span>
											<?php endif; ?>
										</div>



									<div class="form-group <?php echo e($errors->has('location') ? ' has-error' : ''); ?>">
											<label for="location">Choose location on map</label>

										</div>
										<div class="form-group <?php echo e($errors->has('loc-add') ? ' has-error' : ''); ?>">
										<input type="text" class="form-control margin-bottom-5" name="loc-add"  id="loc-add" value="<?php echo e(old('loc-add')); ?>" placeholder="Enter your city">

										<div id="somecomponent" style="width: 490px; height: 400px; margin-left: -14px;margin-bottom: 14px;margin-left:0px"></div>
										<input type="hidden" name="loc-lat" id="loc-lat" value="<?php echo e($healthcare[0]['latitude']); ?>">
										<input type="hidden" name="loc-lon" id="loc-lon" value="<?php echo e($healthcare[0]['longtitude']); ?>">
											<input type="hidden" name="loc-rad" id="loc-rad">
									</div>
									<div class="form-group <?php echo e($errors->has('photos') ? ' has-error' : ''); ?>">
											<label for="photos">Choose Mutiple Photos * (Max :10mb, 50 files)</label>
											<input type="file" name="photos[]" multiple="" />
											<?php if($errors->has('photos')): ?>
												<span class="help-block">
													<strong><?php echo e($errors->first('photos')); ?></strong>
												</span>
											<?php endif; ?>


										</div>
										<div class="form-group <?php echo e($errors->has('payment_mode') ? ' has-error' : ''); ?>">
											<label for="payment_mode">Payment Mode for registration *</label>
											<select  class="form-control" id="payment_mode" name="payment_mode" required>
												<option value="">Select your payment mode</option>
												<option value="cheque">Cheque</option>
												<option value="dd">DD</option>
												<option value="net_banking">Net banking</option>
												<option value="other">Other</option>
											</select>
											<?php if($errors->has('payment_mode')): ?>
												<span class="help-block">
													<strong><?php echo e($errors->first('payment_mode')); ?></strong>
												</span>
											<?php endif; ?>
										</div>


										<input type="hidden" name="type" value="2" />

										</fieldset>
										<div class="form-group">
											<input type="button"  value="Edit" id="edit-healthcare" style="display:none" class="lp-secondary-btn width-full btn-second-hover">
									<br><br>
											<input type="submit"  value="Review" id="submit-healthcare" class="lp-secondary-btn width-full btn-first-hover">

										</div>
									</form>














									<form id="add-healthcare" class="form-horizontal padding-top-15"role="form" method="POST" action="<?php echo e(url('/healthcare/update')); ?>" enctype='multipart/form-data'>
                       					 <?php echo e(csrf_field()); ?>

											<input type="hidden" name="healthcare_id" id="healthcare_id" value="<?php echo e($healthcare[0]['id']); ?>">

										<div class="form-group <?php echo e($errors->has('name') ? ' has-error' : ''); ?>">
											<label for="name">Health care Service name *</label>
											<input type="text" class="form-control" name="name" id="name" value="<?php echo e($healthcare[0]['name']); ?>" required placeholder="Enter health center name">
											<?php if($errors->has('name')): ?>
												<span class="help-block">
													<strong><?php echo e($errors->first('name')); ?></strong>
												</span>
											<?php endif; ?>
										</div>
										<div class="form-group <?php echo e($errors->has('email') ? ' has-error' : ''); ?>">
											<label for="email">Email Address *</label>
											<input type="email" class="form-control" id="email" name="email" value="<?php echo e($healthcare[0]['email']); ?>" placeholder="Enter health center official email" required>
											 <?php if($errors->has('email')): ?>
												<span class="help-block">
													<strong><?php echo e($errors->first('email')); ?></strong>
												</span>
											<?php endif; ?>
										</div>

										<div class="form-group <?php echo e($errors->has('treatment_type') ? ' has-error' : ''); ?>">
											<label for="treatment_type">Type of Treatment *</label>
											<?php $i = 1; ?>
											<?php foreach($selectedTypes as $sTypes): ?>

<select class="form-control treatment-type-<?php echo e($i); ?> margin-top-7" id="treatment_type_<?php echo e($i); ?>" name="treatment_type_<?php echo e($i); ?>" required>
<option value="<?php echo e($sTypes['id']); ?>"><?php echo e($sTypes['name']); ?></option>
										<?php foreach($types as $type): ?>
										<option value="<?php echo e($type['id']); ?>"><?php echo e($type['name']); ?></option>
										<?php endforeach; ?>
</select>
<?php $i++ ?>
<?php endforeach; ?>

<?php for($j = $i;$j <= count($types);$j++): ?>

											<select class="form-control treatment-type-<?php echo e($j); ?> margin-top-7 hide-type" id="treatment_type_<?php echo e($j); ?>" name="treatment_type_<?php echo e($j); ?>" required>
<option value="">Select your treatment type</option>
										<?php foreach($types as $type): ?>
										<option value="<?php echo e($type['id']); ?>"><?php echo e($type['name']); ?></option>
										<?php endforeach; ?>
</select>
<?php endfor; ?>
											<?php if($errors->has('treatment_type')): ?>
												<span class="help-block">
													<strong><?php echo e($errors->first('treatment_type')); ?></strong>
												</span>
											<?php endif; ?>
											<div class="add-type"><i class="fa fa-plus"></i> Add Type</div>
										</div>
											<div class="form-group <?php echo e($errors->has('working_hours') ? ' has-error' : ''); ?>">
											<label for="working_hours">Working Hours ?</label>
									 </div>
									 <div class="form-group <?php echo e($errors->has('working_hours_mon') ? ' has-error' : ''); ?>">
											<div class="col-md-6 no-left-padding" ><select  class="form-control"></div>
											<option value="Monday to Saturday">Monday to Saturday</option>
											</select>
											</div>
											<div class="col-md-3"><select  class="form-control" name="working_hours_mon_from" id="working_hours_mon_from" required>
											<option value="<?php echo e($healthcare[0]['mon_from']); ?>"><?php echo e($healthcare[0]['mon_from']); ?></option>
											<option value="01 AM">01 AM</option>
											<option value="02 AM">02 AM</option>
											<option value="03 AM">03 AM</option>
											<option value="04 AM">04 AM</option>
											<option value="05 AM">05 AM</option>
											<option value="06 AM">06 AM</option>
											<option value="07 AM">07 AM</option>
											<option value="08 AM">08 AM</option>
											<option value="09 AM">09 AM</option>
											<option value="10 AM">10 AM</option>
											<option value="11 AM">11 AM</option>
											<option value="12 PM">12 PM</option>
											<option value="01 PM">01 PM</option>
											<option value="02 PM">02 PM</option>
											<option value="03 PM">03 PM</option>
											<option value="04 PM">04 PM</option>
											<option value="05 PM">05 PM</option>
											<option value="06 PM">06 PM</option>
											<option value="07 PM">07 PM</option>
											<option value="08 PM">08 PM</option>
											<option value="09 PM">09 PM</option>
											<option value="10 PM">10 PM</option>
											<option value="11 PM">11 PM</option>
											<option value="12 AM">12 AM</option>
											</select>
											</div>
											<div class="col-md-3 no-right-padding"><select  class="form-control" name="working_hours_mon_to" id="working_hours_mon_to"  required>
											<option value="<?php echo e($healthcare[0]['mon_to']); ?>"><?php echo e($healthcare[0]['mon_to']); ?></option>
											<option value="01 AM">01 AM</option>
											<option value="02 AM">02 AM</option>
											<option value="03 AM">03 AM</option>
											<option value="04 AM">04 AM</option>
											<option value="05 AM">05 AM</option>
											<option value="06 AM">06 AM</option>
											<option value="07 AM">07 AM</option>
											<option value="08 AM">08 AM</option>
											<option value="09 AM">09 AM</option>
											<option value="10 AM">10 AM</option>
											<option value="11 AM">11 AM</option>
											<option value="12 PM">12 PM</option>
											<option value="01 PM">01 PM</option>
											<option value="02 PM">02 PM</option>
											<option value="03 PM">03 PM</option>
											<option value="04 PM">04 PM</option>
											<option value="05 PM">05 PM</option>
											<option value="06 PM">06 PM</option>
											<option value="07 PM">07 PM</option>
											<option value="08 PM">08 PM</option>
											<option value="09 PM">09 PM</option>
											<option value="10 PM">10 PM</option>
											<option value="11 PM">11 PM</option>
											<option value="12 AM">12 AM</option></select>
											</div>
											<?php if($errors->has('working_hours_mon')): ?>
												<span class="help-block">
													<strong><?php echo e($errors->first('working_hours_mon')); ?></strong>
												</span>
											<?php endif; ?>
										</div>
										<div class="form-group <?php echo e($errors->has('working_hours_sun') ? ' has-error' : ''); ?>">
											<div class="col-md-6 no-left-padding" ><select  class="form-control"></div>
											<option value="Sunday">Sunday</option>
											</select>
											</div>
											<div class="col-md-3"><select  class="form-control" name="working_hours_sun_from" id="working_hours_sun_from"   required>
											<option value="<?php echo e($healthcare[0]['sun_from']); ?>"><?php echo e($healthcare[0]['sun_from']); ?></option>
											<option value="01 AM">01 AM</option>
											<option value="02 AM">02 AM</option>
											<option value="03 AM">03 AM</option>
											<option value="04 AM">04 AM</option>
											<option value="05 AM">05 AM</option>
											<option value="06 AM">06 AM</option>
											<option value="07 AM">07 AM</option>
											<option value="08 AM">08 AM</option>
											<option value="09 AM">09 AM</option>
											<option value="10 AM">10 AM</option>
											<option value="11 AM">11 AM</option>
											<option value="12 PM">12 PM</option>
											<option value="01 PM">01 PM</option>
											<option value="02 PM">02 PM</option>
											<option value="03 PM">03 PM</option>
											<option value="04 PM">04 PM</option>
											<option value="05 PM">05 PM</option>
											<option value="06 PM">06 PM</option>
											<option value="07 PM">07 PM</option>
											<option value="08 PM">08 PM</option>
											<option value="09 PM">09 PM</option>
											<option value="10 PM">10 PM</option>
											<option value="11 PM">11 PM</option>
											<option value="12 AM">12 AM</option>
											</select>
											</div>
											<div class="col-md-3 no-right-padding"><select  class="form-control" name="working_hours_sun_to" id="working_hours_sun_to"   required>
											<option value="<?php echo e($healthcare[0]['sun_to']); ?>"><?php echo e($healthcare[0]['sun_to']); ?></option>
											<option value="01 AM">01 AM</option>
											<option value="02 AM">02 AM</option>
											<option value="03 AM">03 AM</option>
											<option value="04 AM">04 AM</option>
											<option value="05 AM">05 AM</option>
											<option value="06 AM">06 AM</option>
											<option value="07 AM">07 AM</option>
											<option value="08 AM">08 AM</option>
											<option value="09 AM">09 AM</option>
											<option value="10 AM">10 AM</option>
											<option value="11 AM">11 AM</option>
											<option value="12 PM">12 PM</option>
											<option value="01 PM">01 PM</option>
											<option value="02 PM">02 PM</option>
											<option value="03 PM">03 PM</option>
											<option value="04 PM">04 PM</option>
											<option value="05 PM">05 PM</option>
											<option value="06 PM">06 PM</option>
											<option value="07 PM">07 PM</option>
											<option value="08 PM">08 PM</option>
											<option value="09 PM">09 PM</option>
											<option value="10 PM">10 PM</option>
											<option value="11 PM">11 PM</option>
											<option value="12 AM">12 AM</option></select>
											</div>
											<?php if($errors->has('working_hours_sun')): ?>
												<span class="help-block">
													<strong><?php echo e($errors->first('working_hours_sun')); ?></strong>
												</span>
											<?php endif; ?>
										</div>

										<div class="form-group <?php echo e($errors->has('certificate') ? ' has-error' : ''); ?>">
											<label for="certificate">Do you have certification ?</label>
											<select  class="form-control" id="certificate" name="certificate">
<?php if($healthcare[0]['certificate'] == 1): ?>
<option value="1">Yes</option>
<option value="0">No</option>
<?php else: ?>
<option value="0">No</option>
<option value="1">Yes</option>
<?php endif; ?>
</select>
											<?php if($errors->has('certificate')): ?>
												<span class="help-block">
													<strong><?php echo e($errors->first('certificate')); ?></strong>
												</span>
											<?php endif; ?>
										</div>
										<div class="form-group <?php echo e($errors->has('departments') ? ' has-error' : ''); ?>">
											<label for="departments">Departments *</label>
											<input type="text" class="form-control" id="departments" name="departments" value="<?php echo e(old('departments')); ?>" placeholder="Enter departments" required>
											 <?php if($errors->has('departments')): ?>
												<span class="help-block">
													<strong><?php echo e($errors->first('departments')); ?></strong>
												</span>
											<?php endif; ?>
										</div>
										<div class="form-group <?php echo e($errors->has('country') ? ' has-error' : ''); ?>"   required>
											<label for="country">Country *</label>
											<select  class="form-control" id="country" name="country">
<option value="<?php echo e($country[0]['id']); ?>"><?php echo e($country[0]['name']); ?></option>
<?php foreach($countries as $country): ?>
										<option value="<?php echo e($country['id']); ?>"><?php echo e($country['name']); ?></option>
										<?php endforeach; ?>
</select>
											<?php if($errors->has('country')): ?>
												<span class="help-block">
													<strong><?php echo e($errors->first('country')); ?></strong>
												</span>
											<?php endif; ?>
										</div>
										<div class="form-group <?php echo e($errors->has('state') ? ' has-error' : ''); ?>"   required>
											<label for="state">State *</label>
											<select class="form-control" id="state" name="state">

<option value="<?php echo e($state[0]['id']); ?>"><?php echo e($state[0]['name']); ?></option>
</select>
											<?php if($errors->has('state')): ?>
												<span class="help-block">
													<strong><?php echo e($errors->first('state')); ?></strong>
												</span>
											<?php endif; ?>
										</div>
										<div class="form-group <?php echo e($errors->has('city') ? ' has-error' : ''); ?>"   required>
											<label for="city">City *</label>
											<select class="form-control" id="city" name="city">
<option value="<?php echo e($city[0]['id']); ?>"><?php echo e($city[0]['name']); ?></option>
</select>
											<?php if($errors->has('city')): ?>
												<span class="help-block">
													<strong><?php echo e($errors->first('country')); ?></strong>
												</span>
											<?php endif; ?>
										</div>

										<div class="form-group <?php echo e($errors->has('village') ? ' has-error' : ''); ?>"   required>
											<label for="village">Town/Village *</label>
											<input type="text" class="form-control" name="village" id="village" required value="<?php echo e(old('village')); ?>" placeholder="Enter health center town/village">
											<?php if($errors->has('village')): ?>
												<span class="help-block">
													<strong><?php echo e($errors->first('village')); ?></strong>
												</span>
											<?php endif; ?>

										</div>

										<div class="form-group <?php echo e($errors->has('address') ? ' has-error' : ''); ?>">
											<label for="address">Address *</label>
											<textarea class="form-control" name="address" id="address" placeholder="Enter your healthcare center address"  required><?php echo e($healthcare[0]['address']); ?></textarea>
											<?php if($errors->has('address')): ?>
												<span class="help-block">
													<strong><?php echo e($errors->first('address')); ?></strong>
												</span>
											<?php endif; ?>
										</div>
										<div class="form-group <?php echo e($errors->has('pin') ? ' has-error' : ''); ?>">
											<label for="pin">Pin *</label>
											<input type="text" class="form-control" name="pin" id="pin" required value="<?php echo e($healthcare[0]['pin']); ?>" placeholder="Enter health center Pin code">
											<?php if($errors->has('pin')): ?>
												<span class="help-block">
													<strong><?php echo e($errors->first('pin')); ?></strong>
												</span>
											<?php endif; ?>
										</div>
										<div class="form-group <?php echo e($errors->has('contact_name') ? ' has-error' : ''); ?>">
											<label for="contact_name">Contact Person Name </label>
											<input type="text" class="form-control" name="contact_name" required id="contact_name" placeholder="Enter contact person name" value="<?php echo e($healthcare[0]['contact_name']); ?>">
											<?php if($errors->has('contact_name')): ?>
												<span class="help-block">
													<strong><?php echo e($errors->first('contact_name')); ?></strong>
												</span>
											<?php endif; ?>
										</div>
										<div class="form-group <?php echo e($errors->has('contact_email') ? ' has-error' : ''); ?>">
											<label for="contact_email">Contact Person Email </label>
											<input type="text" class="form-control" name="contact_email" required id="contact_email" placeholder="Enter contact person email" value="<?php echo e($healthcare[0]['contact_email']); ?>">
											<?php if($errors->has('contact_email')): ?>
												<span class="help-block">
													<strong><?php echo e($errors->first('contact_email')); ?></strong>
												</span>
											<?php endif; ?>
										</div>
										<div class="form-group <?php echo e($errors->has('mobile') ? ' has-error' : ''); ?>">
											<label for="mobile">Mobile *</label>
											<input type="text" class="form-control" name="mobile" required id="mobile" placeholder="Enter health center mobile number" value="<?php echo e($healthcare[0]['mobile']); ?>" >
											<?php if($errors->has('mobile')): ?>
												<span class="help-block">
													<strong><?php echo e($errors->first('mobile')); ?></strong>
												</span>
											<?php endif; ?>
										</div>
										<div class="form-group <?php echo e($errors->has('phone') ? ' has-error' : ''); ?>">
											<label for="phone">Phone *</label>
											<input type="text" class="form-control" name="phone" required id="phone" placeholder="Enter health center phone number" value="<?php echo e($healthcare[0]['phone']); ?>">
											<?php if($errors->has('phone')): ?>
												<span class="help-block">
													<strong><?php echo e($errors->first('phone')); ?></strong>
												</span>
											<?php endif; ?>
										</div>
										<div class="form-group <?php echo e($errors->has('fax') ? ' has-error' : ''); ?>">
											<label for="fax">Fax</label>
											<input type="text" class="form-control" name="fax"  id="fax" value="<?php echo e($healthcare[0]['fax']); ?>" placeholder="Enter Health center fax">
											<?php if($errors->has('fax')): ?>
												<span class="help-block">
													<strong><?php echo e($errors->first('fax')); ?></strong>
												</span>
											<?php endif; ?>
										</div>
										<div class="form-group <?php echo e($errors->has('website') ? ' has-error' : ''); ?>">
											<label for="website">Website</label>
											<input type="text" class="form-control" name="website"  id="website" value="<?php echo e($healthcare[0]['website']); ?>" placeholder="Enter Health center website address">
											<?php if($errors->has('website')): ?>
												<span class="help-block">
													<strong><?php echo e($errors->first('website')); ?></strong>
												</span>
											<?php endif; ?>
										</div>

										<div class="form-group <?php echo e($errors->has('description') ? ' has-error' : ''); ?>">
											<label for="description">Describe your health care *</label>
											<textarea class="form-control" name="description" required id="description" placeholder="Tell us more about your health centre (less than 200 words)"><?php echo e($healthcare[0]['description']); ?></textarea>
											<?php if($errors->has('description')): ?>
												<span class="help-block">
													<strong><?php echo e($errors->first('description')); ?></strong>
												</span>
											<?php endif; ?>
										</div>

										<div class="form-group <?php echo e($errors->has('fecilities') ? ' has-error' : ''); ?>">
											<label for="fecilities">Available Fecilities</label> <br>
											<label for="fec-lab" class="fecilities-lbl"><input type="checkbox" id="fec-lab" name="fec-lab" class="fecilites-check" value="1" <?php if($healthcare[0]['lab'] == 1): ?> checked <?php endif; ?>> Lab</label>
											<label for="fec-parking" class="fecilities-lbl"><input type="checkbox" id="fec-parking" name="fec-parking" class="fecilites-check" value="1" <?php if($healthcare[0]['parking'] == 1): ?> checked <?php endif; ?>> Parking</label>
									<label for="fec-pharmacy" class="fecilities-lbl"><input type="checkbox" id="fec-pharmacy" name="fec-pharmacy" class="fecilites-check" value="1" <?php if($healthcare[0]['pharmacy'] == 1): ?> checked <?php endif; ?>> Pharmacy</label>
									<label for="fec-wheelchair" class="fecilities-lbl"><input type="checkbox" id="fec-wheelchair" name="fec-wheelchair" class="fecilites-check" value="1" <?php if($healthcare[0]['wheelchair'] == 1): ?> checked <?php endif; ?>> Wheelchair Access</label>
									<label for="fec-ambulance" class="fecilities-lbl"><input type="checkbox" id="fec-ambulance" name="fec-ambulance" class="fecilites-check" value="1" <?php if($healthcare[0]['ambulance'] == 1): ?> checked <?php endif; ?>> Ambulance</label>
									<label for="fec-inpatient" class="fecilities-lbl"><input type="checkbox" id="fec-inpatient" name="fec-inpatient" class="fecilites-check" value="1" <?php if($healthcare[0]['inpatient'] == 1): ?> checked <?php endif; ?>> Inpatient</label>
									<label for="fec-bloodbank" class="fecilities-lbl"><input type="checkbox" id="fec-bloodbank" name="fec-bloodbank" class="fecilites-check" value="1" <?php if($healthcare[0]['bloodbank'] == 1): ?> checked <?php endif; ?>> Blood Bank</label>
									<label for="fec-fitnesscentre" class="fecilities-lbl"><input type="checkbox" id="fec-fitnesscentre" name="fec-fitnesscentre" class="fecilites-check" value="1" <?php if($healthcare[0]['fitness'] == 1): ?> checked <?php endif; ?>> Fitness Centre</label>
									<label for="fec-yoga" class="fecilities-lbl"><input type="checkbox" id="fec-yoga" name="fec-yoga" class="fecilites-check" value="1" <?php if($healthcare[0]['yoga'] == 1): ?> checked <?php endif; ?>> Yoga</label>
									<label for="fec-massage" class="fecilities-lbl"><input type="checkbox" id="fec-massage" name="fec-massage" class="fecilites-check" value="1" <?php if($healthcare[0]['massage'] == 1): ?> checked <?php endif; ?>> Massage</label>
									<label for="fec-sports" class="fecilities-lbl"><input type="checkbox" id="fec-sports" name="fec-sports" class="fecilites-check" value="1" <?php if($healthcare[0]['sports'] == 1): ?> checked <?php endif; ?>> Sports</label>
									<label for="fec-tours" class="fecilities-lbl"><input type="checkbox" id="fec-tours" name="fec-tours" class="fecilites-check" value="1" <?php if($healthcare[0]['tours'] == 1): ?> checked <?php endif; ?>> Tours</label>
									<label for="fec-insurance" class="fecilities-lbl"><input type="checkbox" id="fec-insurance" name="fec-insurance" class="fecilites-check" value="1" <?php if($healthcare[0]['insurance'] == 1): ?> checked <?php endif; ?>> Insurance</label>
										</div>
										<div class="form-group <?php echo e($errors->has('payment') ? ' has-error' : ''); ?>">
											<label for="payment">Payment Modes</label> <br>
											<label for="pay-cash" class="fecilities-lbl"><input type="checkbox" id="pay-cash" name="pay-cash" value="1" class="fecilites-check" <?php if($healthcare[0]['cash'] == 1): ?> checked <?php endif; ?>> Cash</label>
											<label for="pay-creditcard" class="fecilities-lbl"><input type="checkbox" id="pay-creditcard"  value="1" name="pay-creditcard" class="fecilites-check" <?php if($healthcare[0]['credit_card'] == 1): ?> checked <?php endif; ?>> Credit Card</label>
									<label for="pay-debitcard" class="fecilities-lbl"><input type="checkbox" id="pay-debitcard" value="1" name="pay-debitcard" class="fecilites-check" <?php if($healthcare[0]['debit_card'] == 1): ?> checked <?php endif; ?>> Debit Card</label>
									<label for="pay-cheque" class="fecilities-lbl"><input type="checkbox" id="pay-cheque" value="1" name="pay-cheque" class="fecilites-check" <?php if($healthcare[0]['cheque'] == 1): ?> checked <?php endif; ?>> Cheque</label>
										</div>

										<div class="form-group <?php echo e($errors->has('accommodation') ? ' has-error' : ''); ?>">
											<label for="accommodation">Does accommodation available?</label>
											<select  class="form-control" id="accommodation" name="accommodation" required>
<?php if($healthcare[0]['accommodation'] == 1): ?>
<option value="1">Yes</option>
<option value="0">No</option>
<?php else: ?>

<option value="0">No</option>
<option value="1">Yes</option>

<?php endif; ?>
</select>
											<?php if($errors->has('accommodation')): ?>
												<span class="help-block">
													<strong><?php echo e($errors->first('accommodation')); ?></strong>
												</span>
											<?php endif; ?>
										</div>

										<div class="form-group <?php echo e($errors->has('accommodation_type') ? ' has-error' : ''); ?> <?php if($healthcare[0]['food'] == 0): ?>  accommodation-type <?php endif; ?>">
											<label for="accommodation_type">Accomodation Type</label> <br>
											<label for="accommodation_single_ac" class="fecilities-lbl"><input type="checkbox" value="1" id="accommodation_single_ac" name="accommodation_single_ac" class="fecilites-check" <?php if($healthcare[0]['single_ac'] == 1): ?> checked <?php endif; ?>> Single AC</label>
											<label for="accommodation_single_non_ac" class="fecilities-lbl"><input type="checkbox" value="1" id="accommodation_single_non_ac" name="accommodation_single_non_ac" class="fecilites-check" <?php if($healthcare[0]['single_non_ac'] == 1): ?> checked <?php endif; ?>> Single Non AC</label>
									<label for="accommodation_shared" class="fecilities-lbl"><input type="checkbox" id="accommodation_shared" value="1" name="accommodation_shared" class="fecilites-check" <?php if($healthcare[0]['shared'] == 1): ?> checked <?php endif; ?>> Shared Rooms</label>
									<label for="accommodation_general" class="fecilities-lbl"><input type="checkbox" id="accommodation_general" value="1"  name="accommodation_general" class="fecilites-check" <?php if($healthcare[0]['general_ward'] == 1): ?> checked <?php endif; ?>> General Ward</label>
										</div>

<div class="form-group <?php echo e($errors->has('food') ? ' has-error' : ''); ?>">
											<label for="accommodation">Does food available?</label>
											<select  class="form-control" id="food" name="food" required>
<?php if($healthcare[0]['food'] == 1): ?>
<option value="1">Yes</option>
<option value="0">No</option>
<?php else: ?>

<option value="0">No</option>
<option value="1">Yes</option>

<?php endif; ?>
</select>
											<?php if($errors->has('food')): ?>
												<span class="help-block">
													<strong><?php echo e($errors->first('food')); ?></strong>
												</span>
											<?php endif; ?>
										</div>
										<div class="form-group <?php echo e($errors->has('food_types') ? ' has-error' : ''); ?> <?php if($healthcare[0]['food'] == 0): ?>  food-type <?php endif; ?>">
											<label for="food_types">Type of Foods</label> <br>
											<label for="food_veg" class="fecilities-lbl"><input type="checkbox" value="1" id="food_veg" name="food_veg" class="fecilites-check" <?php if($healthcare[0]['veg'] == 1): ?> checked <?php endif; ?>> Veg</label>
											<label for="food_non_veg" class="fecilities-lbl"><input type="checkbox" value="1" id="food_non_veg" name="food_non_veg" class="fecilites-check" <?php if($healthcare[0]['non_veg'] == 1): ?> checked <?php endif; ?>> Non Veg</label>
									<label for="food_organic" class="fecilities-lbl"><input type="checkbox" value="1" id="food_organic" name="food_organic" class="fecilites-check" <?php if($healthcare[0]['organic'] == 1): ?> checked <?php endif; ?>> Organic Food</label>
									<label for="food_personalised" class="fecilities-lbl"><input type="checkbox" value="1" id="food_personalised" name="food_personalised" class="fecilites-check" <?php if($healthcare[0]['personalised_diet'] == 1): ?> checked <?php endif; ?>> Personalised Diet</label>
										</div>
										<div class="form-group <?php echo e($errors->has('price') ? ' has-error' : ''); ?>">
											<label for="price">Price Category *</label>
											<select  class="form-control" id="price" name="price" required>

												<option value="<?php echo e($healthcare[0]['price']); ?>">
												<?php for($i = 0; $i < $healthcare[0]['price'];$i++): ?>
													$
												<?php endfor; ?>
												</option>
												<option value="5">$$$$$</option>
												<option value="4">$$$$</option>
												<option value="3">$$$</option>
												<option value="2">$$</option>
												<option value="1">$</option>

											</select>
											<?php if($errors->has('price')): ?>
												<span class="help-block">
													<strong><?php echo e($errors->first('price')); ?></strong>
												</span>
											<?php endif; ?>
										</div>

<div class="form-group <?php echo e($errors->has('location') ? ' has-error' : ''); ?>">
											<label for="location">Choose location on map</label>

										</div>
										<div id="somecomponent" style="width: 500px; height: 400px; margin-left: -14px;margin-bottom: 14px;"></div>
										<input type="hidden" name="loc-lat" id="loc-lat" value="<?php echo e($healthcare[0]['latitude']); ?>">
										<input type="hidden" name="loc-lon" id="loc-lon" value="<?php echo e($healthcare[0]['longtitude']); ?>">
										<input type="hidden" name="loc-add" id="loc-add">
										<input type="hidden" name="loc-rad" id="loc-rad">

										<?php for($i = 1; $i <= count($photos); $i++): ?>
										<div class="form-group <?php echo e($errors->has('photo_$i') ? ' has-error' : ''); ?>">
											<label for="photo_1">Photo 1 *</label>
											<div id="img_placeholder_<?php echo e($i); ?>"><img src="/images/healthcare/<?php echo e($photos[$i-1]['photo_url']); ?>" height="100" /> </div>
											<?php if($errors->has('photo_$i')): ?>
												<span class="help-block">
													<strong><?php echo e($errors->first('photo_$i')); ?></strong>
												</span>
											<?php endif; ?>
										</div>
										<?php endfor; ?>
										<?php while($i <= 3): ?>
										<div class="form-group <?php echo e($errors->has('photo_$i') ? ' has-error' : ''); ?>">
											<label for="photo_<?php echo e($i); ?>">Photo <?php echo e($i); ?> </label>
											<input type="file" class="form-control" name="photo_<?php echo e($i); ?>" id="photo_<?php echo e($i); ?>" value="<?php echo e(old('photo_$i')); ?>">
											<?php if($errors->has('photo_$i')): ?>
												<span class="help-block">
													<strong><?php echo e($errors->first('photo_$i')); ?></strong>
												</span>
											<?php endif; ?>
										</div>
										<?php $i++; ?>
										<?php endwhile; ?>

										<input type="hidden" name="type" value="2" />
										<div class="form-group">
											<input type="submit" value="Update" class="lp-secondary-btn width-full btn-first-hover">
										</div>
									</form>

								<a class="md-close"><i class="fa fa-close"></i></a>
								</div>

							</div>
						</div>
					</div>


								</div>
							</div>
						</div>
					</div>


				</div>
			</div>
	</section>

<?php $__env->stopSection(); ?>

<?php echo $__env->make('public.layouts.master', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>