<?php $__env->startSection('title', 'Book Health Care'); ?>


<?php $__env->startSection('content'); ?>
<link rel="stylesheet" href="//code.jquery.com/ui/1.12.0/themes/base/jquery-ui.css">
<div id="page">
	<!--==================================Header Open=================================-->
	<header class="">


		
		<div class="md-overlay"></div> <!-- Overlay for Popup -->
							<div id="menu">
								<?php echo $__env->make('public.layouts.headerMob', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
							</div>
		<div class="lp-menu-bar  lp-menu-bar-color">
			<div class="container">
					<div class="row">
						<?php echo $__env->make('public.layouts.logo', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
						
					</div>
				</div>
		</div><!-- ../menu-bar -->
		<div class="page-heading listing-page archive-page ">
			<div class="page-heading-inner-container text-center">
				<h1>Book Health Care</h1>
				<ul class="breadcrumbs">
					<li><a href="/">Home</a></li>
					<li><span>Book Health Care</span></li>
				</ul>
			</div>
			<div class="page-header-overlay"></div>
		</div><!-- ../Home Search Container -->
	</header>
	<!--==================================Header Close=================================-->
	
	<!--==================================Section Open=================================-->
	<section>
		
		<div class="lp-section-row aliceblue">
			<div class="lp-section-content-container-one">
				<div class="container">
					<div class="row">
						<div class="col-md-12">
							<div class="login-form-popup lp-border-radius-8">
								<div class="siginincontainer">
								 
								<h1 class="text-center"><?php if($status == 0): ?> Error! <?php else: ?> Success! <?php endif; ?></h1>
								<div class="alert <?php if($status == 1): ?> alert-success <?php else: ?> alert-danger <?php endif; ?> margin-top-20"><?php if($status == 1): ?> Your <?php if($type == 'password'): ?> password <?php else: ?> email <?php endif; ?> has been changed successfully! <?php else: ?> You entered wrong password <?php endif; ?>
</div>

									
									
<div class="pop-form-bottom">
										<div class="bottom-links" align="center">
											<a href="<?php echo e($back); ?>"><i class="fa fa-chevron-left"></i> Go back to dashboard</a>
										</div>
										
									</div>
									</div>
								<a class="md-close"><i class="fa fa-close"></i></a>
								</div>
								
								
							</div>	
						</div>
					</div>
				</div>
			</div>
		</div><!-- ../section-row -->
	
	</section>
	
<?php $__env->stopSection(); ?>
<?php echo $__env->make('public.layouts.master', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>