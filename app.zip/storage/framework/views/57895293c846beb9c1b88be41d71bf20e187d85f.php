<?php $__env->startSection('title', 'Sign In - Chikitzo'); ?>


<?php $__env->startSection('content'); ?>
<div id="page">
	<!--==================================Header Open=================================-->
	<header class="">



		<div class="md-overlay"></div> <!-- Overlay for Popup -->
							<div id="menu">
								<?php echo $__env->make('public.layouts.headerMob', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
							</div>
		<div class="lp-menu-bar  lp-menu-bar-color">
			<div class="container">
					<div class="row">
						<?php echo $__env->make('public.layouts.logo', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>

					</div>
				</div>
		</div><!-- ../menu-bar -->
		
	</header>
	<!--==================================Header Close=================================-->

	<!--==================================Section Open=================================-->
	<section>

		<div class="lp-section-row aliceblue">
			<div class="lp-section-content-container-one">
				<div class="container">
					<div class="row">
						<div class="col-md-12">
							<div class="login-form-popup lp-border-radius-8">
								<div class="siginincontainer">
									<h1 class="text-center">Sign In</h1>
									<form class="form-horizontal margin-top-30" role="form" method="POST" action="<?php echo e(url('/login')); ?>">
										<?php echo e(csrf_field()); ?>

										<div class="form-group <?php echo e($errors->has('email') ? ' has-error' : ''); ?>">
											<label for="siusername">Email Address *</label>
											<input type="text" class="form-control" id="email" name="email" value="<?php echo e(old('email')); ?>" required />
										<?php if($errors->has('email')): ?>
											<span class="help-block">
												<strong><?php echo e($errors->first('email')); ?></strong>
											</span>
										<?php endif; ?>
										</div>
										<div class="form-group <?php echo e($errors->has('password') ? ' has-error' : ''); ?>">
											<label for="password">Password *</label>
											<input type="password" class="form-control" id="password" name="password" required />
											<?php if($errors->has('password')): ?>
												<span class="help-block">
													<strong><?php echo e($errors->first('password')); ?></strong>
												</span>
											<?php endif; ?>
										</div>
										<div class="form-group">
											<div class="checkbox pad-bottom-10">
												<input id="check1" type="checkbox" name="remember">
												<label for="check1">Keep me signed in</label>
											</div>
										</div>

										<div class="form-group">
											<input type="submit" value="Sign in" class="lp-secondary-btn width-full btn-first-hover" />
										</div>
									</form>
									<div class="pop-form-bottom">
										<div class="bottom-links">
											<a  href="/signup">Not a member? Sign up</a>
											<a  href="/password/reset" class="pull-right">Forgot Password</a>
										</div>

									</div>
								<a class="md-close"><i class="fa fa-close"></i></a>
								</div>


							</div>
						</div>
					</div>
				</div>
			</div>
		</div><!-- ../section-row -->

	</section>

<?php $__env->stopSection(); ?>

<?php echo $__env->make('public.layouts.master', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>