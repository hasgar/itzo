<?php $__env->startSection('title', 'Admin Dashboard'); ?>


<?php $__env->startSection('content'); ?>
<div id="page">
	<!--==================================Header Open=================================-->
	<header class="">


		
		<div class="md-overlay"></div> <!-- Overlay for Popup -->
							<div id="menu">
								<?php echo $__env->make('public.layouts.headerMob', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
							</div>
		<div class="lp-menu-bar  lp-menu-bar-color">
			<div class="container">
					<div class="row">
						<?php echo $__env->make('public.layouts.logo', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
						
					</div>
				</div>
		</div><!-- ../menu-bar -->
		<div class="page-heading listing-page archive-page ">
			<div class="page-heading-inner-container text-center">
				<h1>Admin Dashboard</h1>
				<ul class="breadcrumbs">
					<li><a href="/">Home</a></li>
					<li><span>Admin Dashboard</span></li>
				</ul>
			</div>
			<div class="page-header-overlay"></div>
		</div><!-- ../Home Search Container -->
	</header>
	<!--==================================Header Close=================================-->
	
	<!--==================================Section Open=================================-->
	<section class="aliceblue">
			<div class="dashboard-tabs">
				<div class="container">
					<!-- Nav tabs -->
					<ul class="nav nav-tabs" role="tablist">
						<li class="active">
							<a href="#" role="tab" data-toggle="tab">
								Bookings
							</a>
						</li>
						<li>
							<a href="/admin/users" role="tab" data-toggle="tab">
								Users
							</a>
						</li>
						<li>
							<a href="/admin/healthcares" role="tab" data-toggle="tab">
								Healthcares
							</a>
						</li>
						<li>
							<a href="/admin/settings" role="tab" data-toggle="tab">
								Account Settings
							</a>
						</li>
					</ul>
				</div>
			</div>
			<div class="container">
				<!-- Tab panes -->
				<div class="tab-content">
					<div class="tab-pane fade active in" id="dashborad">
						<div class="dashboard-tab">
							
							
							<div class="user-recent-listings-container">
									<div class="col-md-8"><h3 class="padding-top-35 padding-bottom-35"><?php echo e($booking[0]['user'][0]['name']); ?>'s Bookings</h3></div><div class="col-md-4"><div class="price-plan-button  pull-right">
									<a href="/logout" class="lp-secondary-btn btn-second-hover">Sign Out</a>
								</div></div><div class="user-recent-listings-inner">
									<div class="row lp-list-page-list">
									<?php if(count($booking) > 0): ?>
										<?php foreach($booking as $book): ?>
										<div class="col-md-12 col-sm-6 col-xs-12 lp-list-view">
											<div class="lp-list-view-inner-contianer lp-border lp-border-radius-8 clearfix">
												<div class="lp-list-view-thumb">
													<div class="lp-list-view-thumb-inner">
														<img src="/images/grid/<?php echo e($book['healthcare'][0]['pro_pic']); ?>" alt="list-1">
													</div>
													
												</div>
												<div class="lp-list-view-content">
													<div class="lp-list-view-content-upper">
													<h3 class="booking-id">Booking ID: CH<?php echo e($book['id']); ?></h3>
														<h4><?php echo e($book['user'][0]['name']); ?></h4>
														<div class="user-portfolio-stat padding-top-0">
												<ul>
													<li>
														<i class="fa fa-phone"></i>
														<span><?php echo e($book['user'][0]['mobile']); ?></span>
													</li>
													<li>
														<i class="fa fa-info-circle"></i>
														<span><?php echo e($book['user'][0]['email']); ?></span>
													</li>
													
												</ul>
											</div>
													</div>
													<div class="lp-list-view-content-bottom">
														<ul class="list-style-none list-pt-display">
															<li>
																<span class="lp-list-sp-icon">
																	<i class="fa fa-calendar"></i>
																</span>
																<span class="lp-list-sp-text">
																	<?php echo e(Carbon\Carbon::createFromFormat('Y-m-d H:i:s', $book['created_at'])->format('M d, Y')); ?>

												
																</span>
															</li>
															
															<li>
															<?php if($book['is_confirmed'] == 0): ?>
																<span class="lp-list-sp-icon">
																	<i class="fa fa-history"></i>
																</span>
																<span class="lp-list-sp-text">
																	Confirmation Pending
																</span>
																<?php elseif($book['is_confirmed'] == 2): ?>
																<span class="lp-list-sp-icon">
																	<i class="fa fa-close"></i>
																</span>
																<span class="lp-list-sp-text">
																	Cancelled by Healthcare
																</span>
																<?php elseif($book['is_confirmed'] == 4): ?>
																<span class="lp-list-sp-icon">
																	<i class="fa fa-close"></i>
																</span>
																<span class="lp-list-sp-text">
																	Cancelled by Admin
																</span>
																<?php elseif($book['is_confirmed'] == 3): ?>
																<span class="lp-list-sp-icon">
																	<i class="fa fa-close"></i>
																</span>
																<span class="lp-list-sp-text">
																	Cancelled by You
																</span>
														 <?php elseif($book['is_confirmed'] == 1): ?>
																<span class="lp-list-sp-icon">
																	<i class="fa fa-check"></i>
																</span>
																<span class="lp-list-sp-text">
																	Confirmed
																</span>
														  <?php endif; ?>
															</li>
															
														</ul>
													</div>
												</div>
												<div class="lp-list-view-paypal">
													<div class="lp-list-view-paypal-inner">
														<h4>Manage Booking</h4>
														<div>
															<p></p>
														</div>
														<div class="lp-list-pay-btn">
															 <a href="/admin/chat/<?php echo e($book['id']); ?>/<?php echo e(urlencode($book['user'][0]['name'])); ?>/<?php echo e(urlencode($book['healthcare'][0]['name'])); ?>" > 
																<i class="fa fa-wechat"></i>
																<span>See Chat</span>
														 </a> 
														</div>
														<!-- <div class="lp-list-pay-btn">
															<?php if($book['is_confirmed'] == 0 || $book['is_confirmed'] == 1): ?>  <a href="/healthcare/confirm/<?php echo e($book['id']); ?>/<?php echo e(urlencode($book['user'][0]['name'])); ?>" onclick="return confirm('Are you sure?')"> <?php else: ?> <a href="javascript::void(0)" onclick="alert('Its already cancelled'); return false">  <?php endif; ?>
																<i class="fa fa-check"></i>
																<span>Confirm</span>
															  </a> 
														</div> -->
														<div class="lp-list-pay-btn">
															<?php if($book['is_confirmed'] == 0 || $book['is_confirmed'] == 1): ?>  <a href="/admin/cancel/<?php echo e($book['id']); ?>/<?php echo e(urlencode($book['user'][0]['name'])); ?>" onclick="return confirm('Are you sure?')"> <?php else: ?> <a href="javascript::void(0)" onclick="alert('Its already cancelled'); return false">  <?php endif; ?>
																<i class="fa fa-close"></i>
																<span>Cancel</span>
															  </a> 
														</div>
													</div>
												</div>
											</div>
										</div>
<?php endforeach; ?>
<?php else: ?> 
<div class="col-md-12 col-sm-6 col-xs-12 lp-list-view">
											<div class="lp-list-view-inner-contianer lp-border lp-border-radius-8 clearfix no-bookings" align="center">
<h4 class="no-bookings">No Bookings done</h4>
											</div>
											</div>
<?php endif; ?>
									</div>
								</div>
							</div>
						</div>
					</div>			
					
					
				</div>
			</div>
	</section>

<?php $__env->stopSection(); ?>
<?php echo $__env->make('public.layouts.master', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>