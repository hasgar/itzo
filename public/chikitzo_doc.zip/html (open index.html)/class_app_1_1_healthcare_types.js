var class_app_1_1_healthcare_types =
[
    [ "types", "class_app_1_1_healthcare_types.html#af9ab990c7d7a5e49ae02e16d5623f4b9", null ],
    [ "$guarded", "class_app_1_1_healthcare_types.html#a5758640ec23bdc1a6850649763244e86", null ]
];