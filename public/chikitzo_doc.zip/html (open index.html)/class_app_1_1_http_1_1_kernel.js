var class_app_1_1_http_1_1_kernel =
[
    [ "$middleware", "class_app_1_1_http_1_1_kernel.html#a36a993ea76b635c84749f6e5e6562344", null ],
    [ "$middlewareGroups", "class_app_1_1_http_1_1_kernel.html#a000642ef1cfc62ea5e829d8a3b17431a", null ],
    [ "$routeMiddleware", "class_app_1_1_http_1_1_kernel.html#ae5bf89bfdb0e63f0e05f25a03d805148", null ]
];