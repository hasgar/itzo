var class_add_keys_to_tables1 =
[
    [ "down", "class_add_keys_to_tables1.html#af5fda92f47a449c7a33f9dd5ef5aa6c3", null ],
    [ "up", "class_add_keys_to_tables1.html#a4edef5efd5ab94ce9d17295898ead93a", null ]
];