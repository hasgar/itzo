var class_app_1_1_http_1_1_middleware_1_1_authenticate =
[
    [ "handle", "class_app_1_1_http_1_1_middleware_1_1_authenticate.html#a9a62f11233fd9dce6393364e01b04001", null ]
];