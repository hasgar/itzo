var searchData=
[
  ['new_20version_202_2e0_2e0_2dbeta_20now_20available_20for_20testers_2e_20_5bcheck_20it_5d_28http_3a_2f_2fwww_2eowlgraphic_2ecom_2fowlcarousel2_2f_29',['New version 2.0.0-beta now available for testers. [Check it](http://www.owlgraphic.com/owlcarousel2/)',['../md_ck_copy_public_js_owl_8carousel__r_e_a_d_m_e.html',1,'']]]
];
