var indexSectionsWithContent =
{
  0: "_abcdefhijklmnprstuv",
  1: "abcdefhijklmprstuv",
  2: "ls",
  3: "_abcdhimrstu",
  4: "ln"
};

var indexSectionNames =
{
  0: "all",
  1: "classes",
  2: "namespaces",
  3: "functions",
  4: "pages"
};

var indexSectionLabels =
{
  0: "All",
  1: "Data Structures",
  2: "Namespaces",
  3: "Functions",
  4: "Pages"
};

