var searchData=
[
  ['laravel_20php_20framework',['Laravel PHP Framework',['../md_ck_copy_readme.html',1,'']]]
];
