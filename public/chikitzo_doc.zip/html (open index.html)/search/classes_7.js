var searchData=
[
  ['inspire',['Inspire',['../class_app_1_1_console_1_1_commands_1_1_inspire.html',1,'App::Console::Commands']]],
  ['isadmin',['isAdmin',['../class_app_1_1_http_1_1_middleware_1_1is_admin.html',1,'App::Http::Middleware']]],
  ['ishealthcare',['isHealthcare',['../class_app_1_1_http_1_1_middleware_1_1is_healthcare.html',1,'App::Http::Middleware']]],
  ['isuser',['isUser',['../class_app_1_1_http_1_1_middleware_1_1is_user.html',1,'App::Http::Middleware']]]
];
