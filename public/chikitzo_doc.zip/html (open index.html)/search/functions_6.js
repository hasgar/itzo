var searchData=
[
  ['index',['index',['../class_app_1_1_http_1_1_controllers_1_1_home_controller.html#ab567a949f50e20ea3d95ad062a17e3c3',1,'App::Http::Controllers::HomeController']]]
];
