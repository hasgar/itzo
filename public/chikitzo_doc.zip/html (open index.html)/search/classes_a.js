var searchData=
[
  ['locationcontroller',['LocationController',['../class_app_1_1_http_1_1_controllers_1_1_location_controller.html',1,'App::Http::Controllers']]]
];
