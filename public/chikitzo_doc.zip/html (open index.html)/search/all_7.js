var searchData=
[
  ['handle',['handle',['../class_app_1_1_console_1_1_commands_1_1_inspire.html#a66eb7514ea7f7f8a5738a180b14e9b48',1,'App\Console\Commands\Inspire\handle()'],['../class_app_1_1_http_1_1_middleware_1_1_authenticate.html#a9a62f11233fd9dce6393364e01b04001',1,'App\Http\Middleware\Authenticate\handle()'],['../class_app_1_1_http_1_1_middleware_1_1is_admin.html#acef7660b2651389395d139e8af42d670',1,'App\Http\Middleware\isAdmin\handle()'],['../class_app_1_1_http_1_1_middleware_1_1is_healthcare.html#acef7660b2651389395d139e8af42d670',1,'App\Http\Middleware\isHealthcare\handle()'],['../class_app_1_1_http_1_1_middleware_1_1is_user.html#acef7660b2651389395d139e8af42d670',1,'App\Http\Middleware\isUser\handle()'],['../class_app_1_1_http_1_1_middleware_1_1_redirect_if_authenticated.html#a9a62f11233fd9dce6393364e01b04001',1,'App\Http\Middleware\RedirectIfAuthenticated\handle()']]],
  ['handler',['Handler',['../class_app_1_1_exceptions_1_1_handler.html',1,'App::Exceptions']]],
  ['healthcare',['Healthcare',['../class_app_1_1_healthcare.html',1,'App']]],
  ['healthcarecontroller',['HealthcareController',['../class_app_1_1_http_1_1_controllers_1_1_healthcare_controller.html',1,'App::Http::Controllers']]],
  ['healthcarefecilities',['HealthcareFecilities',['../class_app_1_1_healthcare_fecilities.html',1,'App']]],
  ['healthcaretypes',['HealthcareTypes',['../class_app_1_1_healthcare_types.html',1,'App']]],
  ['homecontroller',['HomeController',['../class_app_1_1_http_1_1_controllers_1_1_home_controller.html',1,'App::Http::Controllers']]]
];
