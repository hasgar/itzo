var searchData=
[
  ['kernel',['Kernel',['../class_app_1_1_console_1_1_kernel.html',1,'Kernel'],['../class_app_1_1_http_1_1_kernel.html',1,'Kernel']]]
];
