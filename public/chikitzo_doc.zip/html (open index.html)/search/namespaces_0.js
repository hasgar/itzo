var searchData=
[
  ['laravel',['Laravel',['../namespace_laravel.html',1,'']]]
];
