var class_app_1_1_healthcare_fecilities =
[
    [ "fecility", "class_app_1_1_healthcare_fecilities.html#a6a89305ca9d6fcef3cc46b1f6c0ddf53", null ],
    [ "$guarded", "class_app_1_1_healthcare_fecilities.html#a5758640ec23bdc1a6850649763244e86", null ]
];