var NAVTREE =
[
  [ "Main Page", "index.html", [
    [ "Technical Stack", "md_ck_copy_public_js_owl_8carousel__r_e_a_d_m_e.html", null ],
    [ "Laravel PHP Framework", "md_ck_copy_readme.html", null ],
    [ "Namespaces", null, [
      [ "Namespace List", "namespaces.html", "namespaces" ]
    ] ],
    [ "Data Structures", "annotated.html", [
      [ "Data Structures", "annotated.html", "annotated_dup" ],
      [ "Data Structure Index", "classes.html", null ],
      [ "Class Hierarchy", "hierarchy.html", "hierarchy" ],
      [ "Data Fields", "functions.html", [
        [ "All", "functions.html", null ],
        [ "Functions", "functions_func.html", null ]
      ] ]
    ] ]
  ] ]
];

var NAVTREEINDEX =
[
".html",
"class_create_user_table.html#af5fda92f47a449c7a33f9dd5ef5aa6c3"
];

var SYNCONMSG = 'click to disable panel synchronisation';
var SYNCOFFMSG = 'click to enable panel synchronisation';
