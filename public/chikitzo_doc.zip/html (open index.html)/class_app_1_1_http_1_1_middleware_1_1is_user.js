var class_app_1_1_http_1_1_middleware_1_1is_user =
[
    [ "handle", "class_app_1_1_http_1_1_middleware_1_1is_user.html#acef7660b2651389395d139e8af42d670", null ]
];