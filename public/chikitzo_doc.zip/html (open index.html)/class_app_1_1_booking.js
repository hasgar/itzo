var class_app_1_1_booking =
[
    [ "healthcare", "class_app_1_1_booking.html#a7aef9fd164bd625799419146384e3310", null ],
    [ "user", "class_app_1_1_booking.html#ae8a275690ff1b618e1947378b0ed73ae", null ],
    [ "$guarded", "class_app_1_1_booking.html#a5758640ec23bdc1a6850649763244e86", null ],
    [ "$table", "class_app_1_1_booking.html#ae8876a14058f368335baccf35af4a22b", null ]
];