var class_database_seeder =
[
    [ "run", "class_database_seeder.html#afb0fafe7e02a3ae1993c01c19fad2bae", null ]
];