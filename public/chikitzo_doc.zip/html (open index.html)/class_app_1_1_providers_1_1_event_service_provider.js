var class_app_1_1_providers_1_1_event_service_provider =
[
    [ "boot", "class_app_1_1_providers_1_1_event_service_provider.html#a704509e3b98d76ea910cc4dc717114b3", null ],
    [ "$listen", "class_app_1_1_providers_1_1_event_service_provider.html#abdfd4689e0597f0b6c63b970c101e810", null ]
];