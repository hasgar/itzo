var class_test_case =
[
    [ "createApplication", "class_test_case.html#ac39b08beb1abc87ef3f463b559d4c7fe", null ],
    [ "$baseUrl", "class_test_case.html#a3f46653370faceec6ea1f4999c3a9ca2", null ]
];