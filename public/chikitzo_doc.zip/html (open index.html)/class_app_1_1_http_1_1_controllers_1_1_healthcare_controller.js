var class_app_1_1_http_1_1_controllers_1_1_healthcare_controller =
[
    [ "aCancelBook", "class_app_1_1_http_1_1_controllers_1_1_healthcare_controller.html#a970a12dd30846a676efaa78b9ab7251c", null ],
    [ "addHealthcare", "class_app_1_1_http_1_1_controllers_1_1_healthcare_controller.html#aa9eec0a30133f21338e9aa984980367c", null ],
    [ "book", "class_app_1_1_http_1_1_controllers_1_1_healthcare_controller.html#a8bf7ba12faa0c3e514290f33a378c965", null ],
    [ "bookHealthcare", "class_app_1_1_http_1_1_controllers_1_1_healthcare_controller.html#add1fb1911343567afe58ad9ce95b9362", null ],
    [ "cancelBook", "class_app_1_1_http_1_1_controllers_1_1_healthcare_controller.html#a938d8255ddc15f8af3c9927b7cdd0c61", null ],
    [ "cancelBooking", "class_app_1_1_http_1_1_controllers_1_1_healthcare_controller.html#a07a14c4e4f90ec760aa6fc5f7f11d472", null ],
    [ "confirmBook", "class_app_1_1_http_1_1_controllers_1_1_healthcare_controller.html#a1277a5631bb043d8493457e8b8af3358", null ],
    [ "selectHealthcare", "class_app_1_1_http_1_1_controllers_1_1_healthcare_controller.html#ae3a0e8c73a8efd975906e3bf66c7f67b", null ],
    [ "showHealthcare", "class_app_1_1_http_1_1_controllers_1_1_healthcare_controller.html#ae7ada52a251a58c40805a4453c9e16b5", null ],
    [ "typeHealthcares", "class_app_1_1_http_1_1_controllers_1_1_healthcare_controller.html#a5bc840bc3656fa4593e1f7879c4d41df", null ],
    [ "update", "class_app_1_1_http_1_1_controllers_1_1_healthcare_controller.html#a19744baad9341173e46c188a4dcb0c26", null ]
];