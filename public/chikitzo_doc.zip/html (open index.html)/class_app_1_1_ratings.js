var class_app_1_1_ratings =
[
    [ "user", "class_app_1_1_ratings.html#ae8a275690ff1b618e1947378b0ed73ae", null ],
    [ "$guarded", "class_app_1_1_ratings.html#a5758640ec23bdc1a6850649763244e86", null ],
    [ "$table", "class_app_1_1_ratings.html#ae8876a14058f368335baccf35af4a22b", null ]
];