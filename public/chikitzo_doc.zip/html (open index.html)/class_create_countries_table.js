var class_create_countries_table =
[
    [ "down", "class_create_countries_table.html#af5fda92f47a449c7a33f9dd5ef5aa6c3", null ],
    [ "up", "class_create_countries_table.html#a4edef5efd5ab94ce9d17295898ead93a", null ]
];