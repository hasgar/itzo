var class_app_1_1_http_1_1_controllers_1_1_rating_controller =
[
    [ "__construct", "class_app_1_1_http_1_1_controllers_1_1_rating_controller.html#a095c5d389db211932136b53f25f39685", null ],
    [ "addRating", "class_app_1_1_http_1_1_controllers_1_1_rating_controller.html#a58d258352672303cbd493442b54096ae", null ]
];