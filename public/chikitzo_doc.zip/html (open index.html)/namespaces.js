var namespaces =
[
    [ "Laravel", "namespace_laravel.html", null ],
    [ "Sentinel", "namespace_sentinel.html", null ]
];