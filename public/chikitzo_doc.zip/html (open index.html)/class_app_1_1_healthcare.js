var class_app_1_1_healthcare =
[
    [ "city", "class_app_1_1_healthcare.html#a2a1a1baf063b1d835a94f918c0d78422", null ],
    [ "photo", "class_app_1_1_healthcare.html#ab352eaa046e4c09b64354907a53eefce", null ],
    [ "rating", "class_app_1_1_healthcare.html#aadccbea6c804107c84e71dc0551de4a4", null ],
    [ "$guarded", "class_app_1_1_healthcare.html#a5758640ec23bdc1a6850649763244e86", null ],
    [ "$table", "class_app_1_1_healthcare.html#ae8876a14058f368335baccf35af4a22b", null ]
];