var class_app_1_1_user =
[
    [ "$fillable", "class_app_1_1_user.html#a6a90e74ccdf5efd70d51d10c906f8e32", null ],
    [ "$hidden", "class_app_1_1_user.html#a4a374564d2858d8ae869a8fb890aad56", null ]
];