var hierarchy =
[
    [ "Authenticatable", null, [
      [ "User", "class_app_1_1_user.html", null ]
    ] ],
    [ "Authenticate", "class_app_1_1_http_1_1_middleware_1_1_authenticate.html", null ],
    [ "BaseController", null, [
      [ "Controller", "class_app_1_1_http_1_1_controllers_1_1_controller.html", [
        [ "AuthController", "class_app_1_1_http_1_1_controllers_1_1_auth_1_1_auth_controller.html", null ],
        [ "PasswordController", "class_app_1_1_http_1_1_controllers_1_1_auth_1_1_password_controller.html", null ],
        [ "HealthcareController", "class_app_1_1_http_1_1_controllers_1_1_healthcare_controller.html", null ],
        [ "HomeController", "class_app_1_1_http_1_1_controllers_1_1_home_controller.html", null ],
        [ "LocationController", "class_app_1_1_http_1_1_controllers_1_1_location_controller.html", null ],
        [ "RatingController", "class_app_1_1_http_1_1_controllers_1_1_rating_controller.html", null ],
        [ "UserController", "class_app_1_1_http_1_1_controllers_1_1_user_controller.html", null ]
      ] ]
    ] ],
    [ "BaseEncrypter", null, [
      [ "EncryptCookies", "class_app_1_1_http_1_1_middleware_1_1_encrypt_cookies.html", null ]
    ] ],
    [ "BaseVerifier", null, [
      [ "VerifyCsrfToken", "class_app_1_1_http_1_1_middleware_1_1_verify_csrf_token.html", null ]
    ] ],
    [ "ConsoleKernel", null, [
      [ "Kernel", "class_app_1_1_console_1_1_kernel.html", null ]
    ] ],
    [ "Event", "class_app_1_1_events_1_1_event.html", null ],
    [ "ExceptionHandler", null, [
      [ "Handler", "class_app_1_1_exceptions_1_1_handler.html", null ]
    ] ],
    [ "HttpKernel", null, [
      [ "Kernel", "class_app_1_1_http_1_1_kernel.html", null ]
    ] ],
    [ "isAdmin", "class_app_1_1_http_1_1_middleware_1_1is_admin.html", null ],
    [ "isHealthcare", "class_app_1_1_http_1_1_middleware_1_1is_healthcare.html", null ],
    [ "isUser", "class_app_1_1_http_1_1_middleware_1_1is_user.html", null ],
    [ "Job", "class_app_1_1_jobs_1_1_job.html", null ],
    [ "RedirectIfAuthenticated", "class_app_1_1_http_1_1_middleware_1_1_redirect_if_authenticated.html", null ],
    [ "TestCase", null, [
      [ "TestCase", "class_test_case.html", [
        [ "ExampleTest", "class_example_test.html", null ]
      ] ]
    ] ],
    [ "Command", null, [
      [ "Inspire", "class_app_1_1_console_1_1_commands_1_1_inspire.html", null ]
    ] ],
    [ "FormRequest", null, [
      [ "Request", "class_app_1_1_http_1_1_requests_1_1_request.html", null ]
    ] ],
    [ "Migration", null, [
      [ "AddKeysToTables", "class_add_keys_to_tables.html", null ],
      [ "AddKeysToTables1", "class_add_keys_to_tables1.html", null ],
      [ "CreateAvailabilityTable", "class_create_availability_table.html", null ],
      [ "CreateBookingTable", "class_create_booking_table.html", null ],
      [ "CreateCitiesTable", "class_create_cities_table.html", null ],
      [ "CreateConversationTable", "class_create_conversation_table.html", null ],
      [ "CreateCountriesTable", "class_create_countries_table.html", null ],
      [ "CreateExtraTable", "class_create_extra_table.html", null ],
      [ "CreateFecilitiesTable", "class_create_fecilities_table.html", null ],
      [ "CreateHealthcareExtraTable", "class_create_healthcare_extra_table.html", null ],
      [ "CreateHealthcarefecilitiesTable", "class_create_healthcarefecilities_table.html", null ],
      [ "CreateHealthcareTable", "class_create_healthcare_table.html", null ],
      [ "CreateHealthcareTypesTable", "class_create_healthcare_types_table.html", null ],
      [ "CreateMessagesTable", "class_create_messages_table.html", null ],
      [ "CreatePhotosTable", "class_create_photos_table.html", null ],
      [ "CreateRatingTable", "class_create_rating_table.html", null ],
      [ "CreateStatesTable", "class_create_states_table.html", null ],
      [ "CreateTypesTable", "class_create_types_table.html", null ],
      [ "CreateUserTable", "class_create_user_table.html", null ],
      [ "MigrationCartalystSentinel", "class_migration_cartalyst_sentinel.html", null ]
    ] ],
    [ "Model", null, [
      [ "Area", "class_app_1_1_area.html", null ],
      [ "Booking", "class_app_1_1_booking.html", null ],
      [ "Cities", "class_app_1_1_cities.html", null ],
      [ "Conversation", "class_app_1_1_conversation.html", null ],
      [ "Countries", "class_app_1_1_countries.html", null ],
      [ "Fecilities", "class_app_1_1_fecilities.html", null ],
      [ "Healthcare", "class_app_1_1_healthcare.html", null ],
      [ "HealthcareFecilities", "class_app_1_1_healthcare_fecilities.html", null ],
      [ "HealthcareTypes", "class_app_1_1_healthcare_types.html", null ],
      [ "Photos", "class_app_1_1_photos.html", null ],
      [ "Ratings", "class_app_1_1_ratings.html", null ],
      [ "States", "class_app_1_1_states.html", null ],
      [ "Types", "class_app_1_1_types.html", null ],
      [ "Users", "class_app_1_1_users.html", null ]
    ] ],
    [ "Seeder", null, [
      [ "DatabaseSeeder", "class_database_seeder.html", null ]
    ] ],
    [ "ServiceProvider", null, [
      [ "AppServiceProvider", "class_app_1_1_providers_1_1_app_service_provider.html", null ],
      [ "AuthServiceProvider", "class_app_1_1_providers_1_1_auth_service_provider.html", null ],
      [ "EventServiceProvider", "class_app_1_1_providers_1_1_event_service_provider.html", null ],
      [ "RouteServiceProvider", "class_app_1_1_providers_1_1_route_service_provider.html", null ]
    ] ]
];