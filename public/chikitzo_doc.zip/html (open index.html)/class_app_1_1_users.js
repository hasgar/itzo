var class_app_1_1_users =
[
    [ "bookings", "class_app_1_1_users.html#a0f99f07a00cb13e77cd7aa42d1ee5b43", null ],
    [ "$guarded", "class_app_1_1_users.html#a5758640ec23bdc1a6850649763244e86", null ],
    [ "$table", "class_app_1_1_users.html#ae8876a14058f368335baccf35af4a22b", null ]
];