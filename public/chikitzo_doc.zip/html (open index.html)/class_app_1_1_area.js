var class_app_1_1_area =
[
    [ "$fillable", "class_app_1_1_area.html#a6a90e74ccdf5efd70d51d10c906f8e32", null ],
    [ "$hidden", "class_app_1_1_area.html#a4a374564d2858d8ae869a8fb890aad56", null ],
    [ "$table", "class_app_1_1_area.html#ae8876a14058f368335baccf35af4a22b", null ]
];