var class_app_1_1_console_1_1_kernel =
[
    [ "schedule", "class_app_1_1_console_1_1_kernel.html#ac8f0af578c80277b7a25381c6a9e268c", null ],
    [ "$commands", "class_app_1_1_console_1_1_kernel.html#ab63cd62b3b65fd223b6f3d57b6ca754d", null ]
];