var annotated_dup =
[
    [ "App", null, [
      [ "Console", null, [
        [ "Commands", null, [
          [ "Inspire", "class_app_1_1_console_1_1_commands_1_1_inspire.html", "class_app_1_1_console_1_1_commands_1_1_inspire" ]
        ] ],
        [ "Kernel", "class_app_1_1_console_1_1_kernel.html", "class_app_1_1_console_1_1_kernel" ]
      ] ],
      [ "Events", null, [
        [ "Event", "class_app_1_1_events_1_1_event.html", null ]
      ] ],
      [ "Exceptions", null, [
        [ "Handler", "class_app_1_1_exceptions_1_1_handler.html", "class_app_1_1_exceptions_1_1_handler" ]
      ] ],
      [ "Http", null, [
        [ "Controllers", null, [
          [ "Auth", null, [
            [ "AuthController", "class_app_1_1_http_1_1_controllers_1_1_auth_1_1_auth_controller.html", "class_app_1_1_http_1_1_controllers_1_1_auth_1_1_auth_controller" ],
            [ "PasswordController", "class_app_1_1_http_1_1_controllers_1_1_auth_1_1_password_controller.html", "class_app_1_1_http_1_1_controllers_1_1_auth_1_1_password_controller" ]
          ] ],
          [ "Controller", "class_app_1_1_http_1_1_controllers_1_1_controller.html", null ],
          [ "HealthcareController", "class_app_1_1_http_1_1_controllers_1_1_healthcare_controller.html", "class_app_1_1_http_1_1_controllers_1_1_healthcare_controller" ],
          [ "HomeController", "class_app_1_1_http_1_1_controllers_1_1_home_controller.html", "class_app_1_1_http_1_1_controllers_1_1_home_controller" ],
          [ "LocationController", "class_app_1_1_http_1_1_controllers_1_1_location_controller.html", "class_app_1_1_http_1_1_controllers_1_1_location_controller" ],
          [ "RatingController", "class_app_1_1_http_1_1_controllers_1_1_rating_controller.html", "class_app_1_1_http_1_1_controllers_1_1_rating_controller" ],
          [ "UserController", "class_app_1_1_http_1_1_controllers_1_1_user_controller.html", "class_app_1_1_http_1_1_controllers_1_1_user_controller" ]
        ] ],
        [ "Middleware", null, [
          [ "Authenticate", "class_app_1_1_http_1_1_middleware_1_1_authenticate.html", "class_app_1_1_http_1_1_middleware_1_1_authenticate" ],
          [ "EncryptCookies", "class_app_1_1_http_1_1_middleware_1_1_encrypt_cookies.html", "class_app_1_1_http_1_1_middleware_1_1_encrypt_cookies" ],
          [ "isAdmin", "class_app_1_1_http_1_1_middleware_1_1is_admin.html", "class_app_1_1_http_1_1_middleware_1_1is_admin" ],
          [ "isHealthcare", "class_app_1_1_http_1_1_middleware_1_1is_healthcare.html", "class_app_1_1_http_1_1_middleware_1_1is_healthcare" ],
          [ "isUser", "class_app_1_1_http_1_1_middleware_1_1is_user.html", "class_app_1_1_http_1_1_middleware_1_1is_user" ],
          [ "RedirectIfAuthenticated", "class_app_1_1_http_1_1_middleware_1_1_redirect_if_authenticated.html", "class_app_1_1_http_1_1_middleware_1_1_redirect_if_authenticated" ],
          [ "VerifyCsrfToken", "class_app_1_1_http_1_1_middleware_1_1_verify_csrf_token.html", "class_app_1_1_http_1_1_middleware_1_1_verify_csrf_token" ]
        ] ],
        [ "Requests", null, [
          [ "Request", "class_app_1_1_http_1_1_requests_1_1_request.html", null ]
        ] ],
        [ "Kernel", "class_app_1_1_http_1_1_kernel.html", "class_app_1_1_http_1_1_kernel" ]
      ] ],
      [ "Jobs", null, [
        [ "Job", "class_app_1_1_jobs_1_1_job.html", null ]
      ] ],
      [ "Providers", null, [
        [ "AppServiceProvider", "class_app_1_1_providers_1_1_app_service_provider.html", "class_app_1_1_providers_1_1_app_service_provider" ],
        [ "AuthServiceProvider", "class_app_1_1_providers_1_1_auth_service_provider.html", "class_app_1_1_providers_1_1_auth_service_provider" ],
        [ "EventServiceProvider", "class_app_1_1_providers_1_1_event_service_provider.html", "class_app_1_1_providers_1_1_event_service_provider" ],
        [ "RouteServiceProvider", "class_app_1_1_providers_1_1_route_service_provider.html", "class_app_1_1_providers_1_1_route_service_provider" ]
      ] ],
      [ "Area", "class_app_1_1_area.html", "class_app_1_1_area" ],
      [ "Booking", "class_app_1_1_booking.html", "class_app_1_1_booking" ],
      [ "Cities", "class_app_1_1_cities.html", "class_app_1_1_cities" ],
      [ "Conversation", "class_app_1_1_conversation.html", "class_app_1_1_conversation" ],
      [ "Countries", "class_app_1_1_countries.html", "class_app_1_1_countries" ],
      [ "Fecilities", "class_app_1_1_fecilities.html", "class_app_1_1_fecilities" ],
      [ "Healthcare", "class_app_1_1_healthcare.html", "class_app_1_1_healthcare" ],
      [ "HealthcareFecilities", "class_app_1_1_healthcare_fecilities.html", "class_app_1_1_healthcare_fecilities" ],
      [ "HealthcareTypes", "class_app_1_1_healthcare_types.html", "class_app_1_1_healthcare_types" ],
      [ "Photos", "class_app_1_1_photos.html", "class_app_1_1_photos" ],
      [ "Ratings", "class_app_1_1_ratings.html", "class_app_1_1_ratings" ],
      [ "States", "class_app_1_1_states.html", "class_app_1_1_states" ],
      [ "Types", "class_app_1_1_types.html", "class_app_1_1_types" ],
      [ "User", "class_app_1_1_user.html", "class_app_1_1_user" ],
      [ "Users", "class_app_1_1_users.html", "class_app_1_1_users" ]
    ] ],
    [ "AddKeysToTables", "class_add_keys_to_tables.html", "class_add_keys_to_tables" ],
    [ "AddKeysToTables1", "class_add_keys_to_tables1.html", "class_add_keys_to_tables1" ],
    [ "CreateAvailabilityTable", "class_create_availability_table.html", "class_create_availability_table" ],
    [ "CreateBookingTable", "class_create_booking_table.html", "class_create_booking_table" ],
    [ "CreateCitiesTable", "class_create_cities_table.html", "class_create_cities_table" ],
    [ "CreateConversationTable", "class_create_conversation_table.html", "class_create_conversation_table" ],
    [ "CreateCountriesTable", "class_create_countries_table.html", "class_create_countries_table" ],
    [ "CreateExtraTable", "class_create_extra_table.html", "class_create_extra_table" ],
    [ "CreateFecilitiesTable", "class_create_fecilities_table.html", "class_create_fecilities_table" ],
    [ "CreateHealthcareExtraTable", "class_create_healthcare_extra_table.html", "class_create_healthcare_extra_table" ],
    [ "CreateHealthcarefecilitiesTable", "class_create_healthcarefecilities_table.html", "class_create_healthcarefecilities_table" ],
    [ "CreateHealthcareTable", "class_create_healthcare_table.html", "class_create_healthcare_table" ],
    [ "CreateHealthcareTypesTable", "class_create_healthcare_types_table.html", "class_create_healthcare_types_table" ],
    [ "CreateMessagesTable", "class_create_messages_table.html", "class_create_messages_table" ],
    [ "CreatePhotosTable", "class_create_photos_table.html", "class_create_photos_table" ],
    [ "CreateRatingTable", "class_create_rating_table.html", "class_create_rating_table" ],
    [ "CreateStatesTable", "class_create_states_table.html", "class_create_states_table" ],
    [ "CreateTypesTable", "class_create_types_table.html", "class_create_types_table" ],
    [ "CreateUserTable", "class_create_user_table.html", "class_create_user_table" ],
    [ "DatabaseSeeder", "class_database_seeder.html", "class_database_seeder" ],
    [ "ExampleTest", "class_example_test.html", "class_example_test" ],
    [ "MigrationCartalystSentinel", "class_migration_cartalyst_sentinel.html", "class_migration_cartalyst_sentinel" ],
    [ "TestCase", "class_test_case.html", "class_test_case" ]
];