var class_app_1_1_providers_1_1_auth_service_provider =
[
    [ "boot", "class_app_1_1_providers_1_1_auth_service_provider.html#aac5b0612892df74173216568a89e606b", null ],
    [ "$policies", "class_app_1_1_providers_1_1_auth_service_provider.html#a3f85b7feacec002a67ba0b150ae3d222", null ]
];